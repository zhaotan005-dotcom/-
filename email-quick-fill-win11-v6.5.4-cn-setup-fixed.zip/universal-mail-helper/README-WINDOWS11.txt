Universal Mail Helper v6.5.4

Background behavior:
- TempoMailer and Dev Mail run in a separate minimized background popup window for email generation, refresh, domain switching, and verification-code monitoring.
- The mailbox becomes visible only after clicking "打开当前邮箱网站". It is then moved into the current browser window and activated.
- If the browser blocks minimized popup creation, the fallback is an inactive tab. Chrome-based browsers normally allow the minimized background window.

Install or upgrade:
1. Extract this ZIP.
2. Run setup\install-or-upgrade.cmd.
3. Fully close all browser processes, then reopen the browser.
4. First install: enable Developer mode on the extensions page and load unpacked from:
   %LOCALAPPDATA%\UniversalMailHelper\extension
   Upgrade: click "Reload" on the extension card.

Account records are kept in Documents\UniversalMailHelper\accounts.txt and are never deleted by upgrades.
