邮箱快填 v6.7.0

安装或升级：
1. 解压 ZIP。
2. 双击 setup\install-or-upgrade.cmd。
3. 看到绿色“成功”提示后，彻底关闭并重开浏览器。
4. 在扩展管理页点击“重新加载”；首次安装则加载：
   %LOCALAPPDATA%\UniversalMailHelper\extension
