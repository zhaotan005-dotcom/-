// 网页自动填写：检测邮箱输入框 → 询问一次 → 允许的网站自动填入，拒绝的永久屏蔽
(() => {
  const KEY = 'sitePrefs';
  let prefs = {}, email = '', name = '', password = '', code = '', asked = false, host = null, shad = null;

  const origin = () => { try { return location.origin || ''; } catch { return ''; } };
  const pref = () => prefs[origin()];
  const matchKey = e => `${e.type || ''} ${e.name || ''} ${e.id || ''} ${e.placeholder || ''} ${e.autocomplete || ''} ${e.ariaLabel || ''}`.toLowerCase();
  const visible = e => { try { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden' && !e.disabled && !e.readOnly; } catch { return false; } };
  const kindOf = e => {
    const k = matchKey(e);
    if (/email|e-mail|邮箱|邮件地址/.test(k)) return 'email';
    if (/password|密码/.test(k)) return 'password';
    if (e.maxLength === 1) return 'codechar';
    if (/verification|verify|otp|one-time|auth.*code|验证码|校验码|动态码|安全码|邮件码/.test(k)) return 'code';
    if (/username|login|nickname|display.?name|full.?name|用户名|昵称|姓名|名称/.test(k) && !/(email|password)/.test(k)) return 'name';
    return null;
  };
  const put = (e, v) => { try { Object.getOwnPropertyDescriptor(e.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype, 'value').set.call(e, v); e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); return true; } catch { return false; } };
  const inputs = () => [...(document.querySelectorAll('input,textarea') || [])];

  // 只填空字段，绝不覆盖用户已输入的内容
  function fillAll() {
    let n = 0; const all = inputs().filter(visible);
    const ones = all.filter(e => e.maxLength === 1);
    if (code && ones.length >= code.length) ones.slice(0, code.length).forEach((e, i) => { if (!e.value && put(e, code[i])) n++; });
    for (const e of all) {
      if (e.value) continue;
      const k = kindOf(e);
      if (k === 'email' && email && put(e, email)) n++;
      else if (k === 'password' && password && put(e, password)) n++;
      else if (k === 'code' && code && put(e, code)) n++;
      else if (k === 'name' && name && put(e, name)) n++;
    }
    return n;
  }
  function fillCodeOnly() {
    let n = 0; const all = inputs().filter(visible);
    const ones = all.filter(e => e.maxLength === 1);
    if (code && ones.length >= code.length) ones.slice(0, code.length).forEach((e, i) => { if (!e.value && put(e, code[i])) n++; });
    for (const e of all) { if (e.value) continue; if (kindOf(e) === 'code' && code && put(e, code)) n++; }
    return n;
  }
  const isEmailField = e => e && (e.tagName === 'INPUT' || e.tagName === 'TEXTAREA') && kindOf(e) === 'email';

  function hideBubble() { if (host) { try { host.remove(); } catch {} host = null; shad = null; } }
  function showBubble() {
    if (host || !document.body) return;
    asked = true;
    host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;top:14px;right:14px;z-index:2147483647';
    try { shad = host.attachShadow({ mode: 'open' }); } catch { document.body.appendChild(host); shad = host; }
    const box = document.createElement('div');
    box.style.cssText = 'font:13px/1.5 system-ui,sans-serif;background:#fff;color:#1a1a1a;border-radius:12px;box-shadow:0 6px 24px rgba(0,0,0,.22);padding:14px 16px;width:270px;border:1px solid #e3e8e6';
    box.innerHTML = '<div style="display:flex;gap:8px;align-items:flex-start"><div style="flex:1"><b>检测到邮箱输入框</b><div style="color:#5a6a66;margin-top:2px">是否允许在此网页自动填写临时邮箱？</div></div><button data-a="close" style="all:unset;cursor:pointer;color:#9aa5a1;font-size:15px;line-height:1">✕</button></div><div style="display:flex;gap:8px;margin-top:10px"><button data-a="allow" style="all:unset;cursor:pointer;flex:1;text-align:center;background:#0a8f5c;color:#fff;border-radius:8px;padding:7px 0;font-weight:600">允许并填写</button><button data-a="deny" style="all:unset;cursor:pointer;flex:1;text-align:center;background:#eef2f0;color:#41504b;border-radius:8px;padding:7px 0">不允许</button></div><div style="color:#9aa5a1;margin-top:8px">不允许后将屏蔽此网站，不再询问</div>';
    shad.appendChild ? shad.appendChild(box) : 0;
    (shad || host).addEventListener('click', ev => {
      const a = ev.target && ev.target.getAttribute && ev.target.getAttribute('data-a');
      if (!a) return;
      hideBubble();
      if (a === 'close') return;
      const p = Object.assign({}, prefs); p[origin()] = a; prefs = p;
      try { chrome.storage.local.set({ [KEY]: p }); } catch {}
      if (a === 'allow') { const n = fillAll(); toast(n); }
    });
    document.body.appendChild(host);
  }
  function toast(n) {
    const t = document.createElement('div');
    t.style.cssText = 'all:initial;position:fixed;bottom:18px;right:14px;z-index:2147483647';
    const b = document.createElement('div');
    b.style.cssText = 'font:13px system-ui,sans-serif;background:#0a8f5c;color:#fff;border-radius:10px;padding:9px 14px;box-shadow:0 4px 16px rgba(0,0,0,.25)';
    b.textContent = n ? `已自动填写 ${n} 个字段` : '暂无可填写的字段';
    t.appendChild(b); document.body.appendChild(t);
    setTimeout(() => { try { t.remove(); } catch {} }, 2600);
  }
  function decide() { const p = pref(); if (p === 'allow') { fillAll(); return; } if (p === 'deny') return; if (!asked) showBubble(); }

  async function init() {
    const d = await chrome.storage.local.get([KEY, 'email', 'name', 'password', 'code']);
    prefs = d[KEY] || {}; email = d.email || ''; name = d.name || ''; password = d.password || ''; code = d.code || '';
    document.addEventListener('focusin', ev => { try { if (isEmailField(ev.target) && visible(ev.target)) decide(); } catch {} }, true);
    document.addEventListener('change', ev => { try { if (isEmailField(ev.target) && visible(ev.target)) decide(); } catch {} }, true);
  }
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    try {
      if (ch.sitePrefs) prefs = ch.sitePrefs.newValue || {};
      if (ch.email) email = ch.email.newValue || '';
      if (ch.name) name = ch.name.newValue || '';
      if (ch.password) password = ch.password.newValue || '';
      if (ch.code) { code = ch.code.newValue || ''; if (code && pref() === 'allow') fillCodeOnly(); }
    } catch {}
  });
  init();
  if (typeof window !== 'undefined' && window.__AF_TEST__) window.__AF__ = { fillAll, fillCodeOnly, kindOf, visible, decide, _state: () => ({ prefs, email, name, password, code }) };
})();
