@echo off
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-or-upgrade.ps1"
if errorlevel 1 (
  echo.
  echo Installation failed. Please run this file again.
  pause
)
