﻿$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$Host.UI.RawUI.WindowTitle = '邮箱快填 安装与升级'
$PackageRoot = Split-Path $PSScriptRoot -Parent
$InstallRoot = Join-Path $env:LOCALAPPDATA 'UniversalMailHelper'
$ExtensionDir = Join-Path $InstallRoot 'extension'
$HostDir = Join-Path $InstallRoot 'native-host'
$HostName = 'com.tempomailer.account_writer'
$ExtensionIds = @('bngjckajijbbgmbphapbkdbncegnoepn','eckoaicknaihfmlgmibgeipipeonpeoh')
$DataDir = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'UniversalMailHelper'
$RecordFile = Join-Path $DataDir 'accounts.txt'

Write-Host ''
Write-Host '邮箱快填：一键安装与升级' -ForegroundColor Cyan
Write-Host '----------------------------------------'

# Keep user data, replace only program files.
New-Item -ItemType Directory -Force -Path $InstallRoot,$HostDir,$DataDir | Out-Null
if (Test-Path $ExtensionDir) { Remove-Item $ExtensionDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $ExtensionDir | Out-Null

$exclude = @('setup','windows-installer','README-WINDOWS11.txt','INSTALL-README.txt','UPDATE-GUIDE.txt')
Get-ChildItem -LiteralPath $PackageRoot -Force | Where-Object { $exclude -notcontains $_.Name } | ForEach-Object {
  Copy-Item $_.FullName -Destination $ExtensionDir -Recurse -Force
}
Copy-Item (Join-Path $PSScriptRoot 'native-host.ps1') (Join-Path $HostDir 'native-host.ps1') -Force
Copy-Item (Join-Path $PSScriptRoot 'native-host.cmd') (Join-Path $HostDir 'native-host.cmd') -Force

$hostCmd = (Join-Path $HostDir 'native-host.cmd').Replace('\','\\')
$origins = ($ExtensionIds | ForEach-Object { '"chrome-extension://' + $_ + '/"' }) -join ', '
$manifestPath = Join-Path $HostDir 'native-host.json'
$manifest = @"
{
  "name": "$HostName",
  "description": "Universal Mail Helper shared record writer",
  "path": "$hostCmd",
  "type": "stdio",
  "allowed_origins": [$origins]
}
"@
[IO.File]::WriteAllText($manifestPath,$manifest,(New-Object Text.UTF8Encoding($false)))

$registryRoots = @(
 'HKCU:\Software\Google\Chrome\NativeMessagingHosts',
 'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts',
 'HKCU:\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts',
 'HKCU:\Software\Chromium\NativeMessagingHosts',
 'HKCU:\Software\Vivaldi\NativeMessagingHosts'
)
foreach ($root in $registryRoots) {
  $key = Join-Path $root $HostName
  New-Item -Force -Path $key | Out-Null
  Set-Item -Path $key -Value $manifestPath
}
foreach ($dir in @(
  (Join-Path $env:APPDATA 'Opera Software\Opera Stable\NativeMessagingHosts'),
  (Join-Path $env:APPDATA 'Opera Software\Opera GX Stable\NativeMessagingHosts')
)) {
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  Copy-Item $manifestPath (Join-Path $dir ($HostName+'.json')) -Force
}
if (!(Test-Path $RecordFile)) {
  [IO.File]::WriteAllText($RecordFile,"Account Records`r`n========================================`r`n",(New-Object Text.UTF8Encoding($true)))
}

# Desktop helper opens the correct extension folder and browser extension page.
$desktop = [Environment]::GetFolderPath('Desktop')
$helper = Join-Path $InstallRoot 'open-extension-setup.cmd'
$helperText = @"
@echo off
start "" "$ExtensionDir"
start "" "chrome://extensions"
start "" "edge://extensions"
"@
[IO.File]::WriteAllText($helper,$helperText,(New-Object Text.ASCIIEncoding))
$shortcut = Join-Path $desktop 'Email Quick Fill Setup.lnk'
$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut($shortcut)
$lnk.TargetPath = $helper
$lnk.WorkingDirectory = $InstallRoot
$lnk.Description = 'Open the installed extension folder and browser extension page'
$lnk.Save()

$manifestText = [IO.File]::ReadAllText((Join-Path $ExtensionDir 'manifest.json'), [Text.Encoding]::UTF8)
$versionMatch = [regex]::Match($manifestText, '"version"\s*:\s*"([^"]+)"')
if (!$versionMatch.Success) { throw 'Cannot read extension version from manifest.json' }
$version = $versionMatch.Groups[1].Value
$report = Join-Path $InstallRoot 'install-report.txt'
@(
 "Status: OK",
 "Version: $version",
 "Extension folder: $ExtensionDir",
 "Native host: $manifestPath",
 "Record file: $RecordFile"
) | Set-Content $report -Encoding UTF8

Write-Host ''
Write-Host "成功：邮箱快填 $version 已安装或升级完成。" -ForegroundColor Green
Write-Host "插件固定目录：$ExtensionDir"
Write-Host "账号记录文件：$RecordFile"
Write-Host ''
Write-Host '接下来请完成浏览器操作：' -ForegroundColor Yellow
Write-Host '1. 彻底关闭并重新打开浏览器。'
Write-Host '2. 打开扩展管理页，并开启开发者模式。'
Write-Host '3. 首次安装时，点击“加载已解压的扩展程序”，选择上面的插件固定目录。'
Write-Host '以后升级只需运行新版安装包里的 install-or-upgrade.cmd，再到扩展页点击“重新加载”。'
Read-Host '按 Enter 键退出'
