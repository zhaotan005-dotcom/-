$ErrorActionPreference = 'Stop'
$stdin = [Console]::OpenStandardInput()
$stdout = [Console]::OpenStandardOutput()
function Read-NativeMessage {
  $lengthBytes = New-Object byte[] 4
  if ($stdin.Read($lengthBytes, 0, 4) -ne 4) { return $null }
  $length = [BitConverter]::ToInt32($lengthBytes, 0)
  $data = New-Object byte[] $length
  $offset = 0
  while ($offset -lt $length) { $read = $stdin.Read($data, $offset, $length - $offset); if ($read -le 0) { break }; $offset += $read }
  return [Text.Encoding]::UTF8.GetString($data, 0, $offset) | ConvertFrom-Json
}
function Send-NativeMessage($obj) {
  $json = $obj | ConvertTo-Json -Compress -Depth 5
  $data = [Text.Encoding]::UTF8.GetBytes($json)
  $len = [BitConverter]::GetBytes([int]$data.Length)
  $stdout.Write($len, 0, 4); $stdout.Write($data, 0, $data.Length); $stdout.Flush()
}
try {
  $msg = Read-NativeMessage
  if ($null -eq $msg) { exit 0 }
  $dir = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'UniversalMailHelper'
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $file = Join-Path $dir 'accounts.txt'
  if ($msg.action -eq 'append') {
    $r = $msg.record
    $block = "Email: $($r.email)`r`nName: $($r.name)`r`nPassword: $($r.password)`r`nTime: $($r.time)`r`n----------------------------------------`r`n"
    [IO.File]::AppendAllText($file, $block, (New-Object Text.UTF8Encoding($true)))
    Send-NativeMessage @{ok=$true;path=$file}
  } elseif ($msg.action -eq 'open') {
    if (!(Test-Path $file)) { [IO.File]::WriteAllText($file, "Account Records`r`n========================================`r`n", (New-Object Text.UTF8Encoding($true))) }
    Start-Process notepad.exe -ArgumentList ('"' + $file + '"')
    Send-NativeMessage @{ok=$true;path=$file}
  } elseif ($msg.action -eq 'ping') {
    Send-NativeMessage @{ok=$true;path=$file}
  } else { Send-NativeMessage @{ok=$false;error='Unknown action'} }
} catch { Send-NativeMessage @{ok=$false;error=$_.Exception.Message} }
