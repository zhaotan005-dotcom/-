$ErrorActionPreference='Stop'
$HostName='com.tempomailer.account_writer'
$InstallRoot=Join-Path $env:LOCALAPPDATA 'UniversalMailHelper'
$roots=@('HKCU:\Software\Google\Chrome\NativeMessagingHosts','HKCU:\Software\Microsoft\Edge\NativeMessagingHosts','HKCU:\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts','HKCU:\Software\Chromium\NativeMessagingHosts','HKCU:\Software\Vivaldi\NativeMessagingHosts')
foreach($r in $roots){$k=Join-Path $r $HostName;if(Test-Path $k){Remove-Item $k -Recurse -Force}}
if(Test-Path $InstallRoot){Remove-Item $InstallRoot -Recurse -Force}
Write-Host 'Program removed. Your Documents\UniversalMailHelper\accounts.txt file was kept.' -ForegroundColor Green
Read-Host 'Press Enter to exit'
