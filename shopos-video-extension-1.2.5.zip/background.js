// ShopOS Video Studio - background (service_worker for Chromium / event page for Firefox Android)
// Auth: Clerk cookies (from the user's normal app.shopos.ai login) -> mint short-lived JWT -> call api.pro.shopos.ai

const CLERK_API = 'https://clerk.app.shopos.ai/v1';
const CLERK_QS = '__clerk_api_version=2026-05-12&_clerk_js_version=6.38.0';
const API_BASE = 'https://api.pro.shopos.ai';

// token cache (JWT lives ~60s; refresh at 45s)
let cachedToken = null; // { jwt, wsId, ts }

function b64urlDecode(s) {
  const pad = s.length % 4 === 0 ? '' : '='.repeat(4 - (s.length % 4));
  const b64 = s.replace(/-/g, '+').replace(/_/g, '/') + pad;
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}

function decodeJwtPayload(jwt) {
  try {
    return JSON.parse(b64urlDecode(jwt.split('.')[1]));
  } catch (e) {
    return null;
  }
}

async function clerkGetClient() {
  const res = await fetch(`${CLERK_API}/client?${CLERK_QS}`, {
    method: 'GET',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' }
  });
  if (!res.ok) throw new Error(`Clerk client ${res.status}`);
  return res.json();
}

async function clerkMintToken(sessionId) {
  const res = await fetch(`${CLERK_API}/client/sessions/${sessionId}/tokens?${CLERK_QS}`, {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' }
  });
  if (!res.ok) throw new Error(`Clerk token ${res.status}`);
  return res.json();
}

// Mint a JWT from inside a real app.shopos.ai tab. Mobile browsers (Firefox
// Android dFPI / Kiwi cookie rules) may partition or block the service
// worker's access to Clerk's cross-site cookies, but a normal page on
// app.shopos.ai always sees them — same as the website itself.
function tabAuthFunc(clerkApi, qs) {
  return (async () => {
    try {
      const res = await fetch(`${clerkApi}/client?${qs}`, {
        method: 'GET',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' }
      });
      if (!res.ok) throw new Error('Clerk client ' + res.status);
      const j = await res.json();
      const body = j.response || j.client || j;
      const sessions = body.sessions || [];
      const active = sessions.find((s) => s.status === 'active') || sessions[0];
      if (!active) {
        const err = new Error('NOT_LOGGED_IN');
        err.code = 'NOT_LOGGED_IN';
        throw err;
      }
      const t = await fetch(`${clerkApi}/client/sessions/${active.id}/tokens?${qs}`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' }
      });
      if (!t.ok) throw new Error('Clerk token ' + t.status);
      const tj = await t.json();
      if (!tj.jwt) throw new Error('NO_JWT');
      return { jwt: tj.jwt };
    } catch (e) {
      return { error: String(e && e.message || e), code: e.code || null };
    }
  })();
}

function tabWaitComplete(tabId, timeout) {
  return new Promise((resolve) => {
    const t0 = Date.now();
    const check = () => {
      try {
        chrome.tabs.get(tabId, (tab) => {
          if (chrome.runtime.lastError) return resolve(false);
          if (tab && tab.status === 'complete') return resolve(true);
          if (Date.now() - t0 > timeout) return resolve(false);
          setTimeout(check, 500);
        });
      } catch (e) { resolve(false); }
    };
    check();
  });
}

function withTimeout(promise, ms, tag) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => {
      const err = new Error(tag + ' timeout');
      err.code = 'AUTH_TIMEOUT';
      reject(err);
    }, ms))
  ]);
}

async function authViaTab() {
  if (typeof chrome === 'undefined' || !chrome.scripting || !chrome.tabs) {
    const err = new Error('NO_SCRIPTING_API');
    err.code = 'NO_SCRIPTING_API';
    throw err;
  }
  const url = 'https://app.shopos.ai/home';
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: 'https://app.shopos.ai/*' }); } catch (e) { tabs = []; }
  let tabId = null;
  if (tabs && tabs.length) {
    tabId = tabs[0].id;
  } else {
    const t = await chrome.tabs.create({ url, active: false });
    tabId = t.id;
    const ok = await tabWaitComplete(tabId, 10000);
    if (!ok) {
      // background tabs may not load on mobile; bring it to front once
      try { await chrome.tabs.update(tabId, { active: true }); } catch (e) {}
      await tabWaitComplete(tabId, 15000);
    }
  }
  if (!tabId) throw new Error('NO_TAB');
  const results = await withTimeout(chrome.scripting.executeScript({
    target: { tabId },
    world: 'ISOLATED',
    func: tabAuthFunc,
    args: [CLERK_API, CLERK_QS]
  }), 25000, 'inject');
  const r = results && results[0] && results[0].result;
  if (!r) throw new Error('TAB_AUTH_EMPTY');
  if (r.error) {
    const err = new Error(r.error);
    err.code = r.code || null;
    throw err;
  }
  return r.jwt;
}

// Returns { jwt, wsId, ts }
async function getAuth(force = false) {
  if (!force && cachedToken) {
    const age = (Date.now() - cachedToken.ts) / 1000;
    if (age < 45) return cachedToken;
  }
  let jwt = null;
  let swErr = null;
  // fast path: service worker fetch (works on desktop)
  try {
    jwt = await (async () => {
      const client = await clerkGetClient();
      const body = client.response || client.client || client;
      const sessions = body.sessions || [];
      const active = sessions.find((s) => s.status === 'active') || sessions[0];
      if (!active) {
        const err = new Error('NOT_LOGGED_IN');
        err.code = 'NOT_LOGGED_IN';
        throw err;
      }
      const tokRes = await clerkMintToken(active.id);
      if (!tokRes.jwt) throw new Error('NO_JWT');
      return tokRes.jwt;
    })();
  } catch (e) {
    swErr = e;
  }
  // fallback: mint inside an app.shopos.ai tab (works on mobile)
  if (!jwt) {
    try {
      jwt = await authViaTab();
    } catch (e) {
      if (e.code === 'NOT_LOGGED_IN') throw e;
      throw (swErr || e);
    }
  }
  cachedToken = { jwt, wsId: decodeJwtPayload(jwt)?.o?.id || null, ts: Date.now() };
  return cachedToken;
}

async function apiCall(path, { method = 'GET', body = null, auth } = {}) {
  const headers = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${auth.jwt}`
  };
  if (auth.wsId) headers['x-workspace-id'] = auth.wsId;
  const fetchOnce = () => Promise.race([
    fetch(`${API_BASE}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : null
    }),
    new Promise((_, reject) => setTimeout(() => reject(new Error('request timeout (60s)')), 60000))
  ]);
  const res = await fetchOnce();
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (e) { data = { raw: text }; }
  return { status: res.status, ok: res.ok, data };
}

async function apiWithAuth(path, opts = {}) {
  let auth;
  try {
    auth = await getAuth();
  } catch (e) {
    return { status: 401, ok: false, error: e.message, code: e.code || null };
  }
  let r = await apiCall(path, { ...opts, auth });
  if (r.status === 401) {
    try {
      auth = await getAuth(true);
      r = await apiCall(path, { ...opts, auth });
    } catch (e) {
      return { status: 401, ok: false, error: e.message, code: e.code || null };
    }
  }
  return r;
}

const messageHandlers = {
  async status() {
    try {
      const auth = await getAuth();
      return { loggedIn: true, wsId: auth.wsId };
    } catch (e) {
      // With the tab-based fallback, NOT_LOGGED_IN means the user truly has
      // no ShopOS session in this browser (checked inside a real app tab).
      const code = e.code || null;
      let reason = 'clerk-unreachable';
      if (code === 'NOT_LOGGED_IN') reason = 'no-session';
      else if (code === 'NO_SCRIPTING_API' || code === 'NO_TAB') reason = 'no-tab';
      return { loggedIn: false, error: String(e && e.message || e), code, reason };
    }
  },

  async balance() {
    return apiWithAuth('/credits/balance');
  },

  async models() {
    return apiWithAuth('/cowork/creative-studio/models?frames=1');
  },

  async cost(payload) {
    const body = { mode: 'video_gen', modelConfig: payload.modelConfig };
    return apiWithAuth('/cowork/creative-studio/cost', { method: 'POST', body });
  },

  // Popup does the media uploads itself (files never travel through messaging);
  // it only needs the short-lived JWT + workspace id minted here.
  async getAuthInfo(payload) {
    try {
      const auth = await getAuth(!!(payload && payload.force));
      return { jwt: auth.jwt, wsId: auth.wsId };
    } catch (e) {
      return { error: String(e && e.message || e), code: e.code || null };
    }
  },

  async generate(payload) {
    const body = {
      mode: 'video_gen',
      prompt: payload.prompt,
      modelConfig: payload.modelConfig,
      generationCount: payload.generationCount || 1,
      enhancePrompt: !!payload.enhancePrompt
    };
    // Reference assets: [{url, type:'image', role:'reference'}]
    // (video references are silently dropped by the render pipeline — verified 2026-10)
    if (Array.isArray(payload.uploadedAssets) && payload.uploadedAssets.length) {
      body.uploadedAssets = payload.uploadedAssets;
    }
    return apiWithAuth('/cowork/creative-studio/requests', { method: 'POST', body });
  },

  async generations(payload) {
    const page = (payload && payload.page) || 1;
    const size = (payload && payload.size) || 10;
    return apiWithAuth(`/cowork/creative-studio/generations/me?page=${page}&size=${size}`);
  },

  // Agent-pipeline mode: create a chat and let the server-side agent run the
  // videoDirector/generateVideo tool. Billing is settled afterwards and clamped
  // to the available balance (can exceed balance as long as balance > 0).
  async agentGenerate(payload) {
    let text = payload.text;
    if (!text) return { status: 400, ok: false, error: 'empty text' };
    // Chat attachment schema is not publicly stable; pass reference URLs inline
    // so the agent's generateVideo tool can ingest them from the message body.
    if (Array.isArray(payload.referenceUrls) && payload.referenceUrls.length) {
      text += '\n\n参考素材（生成时直接使用这些链接）：\n' + payload.referenceUrls.map((u, i) => `${i + 1}. ${u}`).join('\n');
    }
    const create = await apiWithAuth('/cowork/chats', { method: 'POST', body: { title: 'New chat', version: 'v3' } });
    if (!create.ok) return create;
    const chatId = (create.data && (create.data.id || (create.data.data && create.data.data.id)));
    if (!chatId) return { status: 500, ok: false, error: 'no chat id', data: create.data };

    const nanoidAlphabet = 'useandom-26T198340PX75pxJACKVERYMINDBUSHWOLFGQZbfghjklqvwyzrict';
    let msgId = '';
    for (let i = 0; i < 21; i++) msgId += nanoidAlphabet[Math.floor(Math.random() * nanoidAlphabet.length)];

    const body = {
      chat_id: chatId,
      version: 'v3',
      timezone: 'UTC',
      content: [
        { type: 'generation_config', data: payload.generationConfig || { mode: 'image', modelId: 'gemini-nano-banana-2.1', modelConfig: { modelName: 'gemini-nano-banana-2.1', aspectRatio: '1:1', resolution: '2K' } } },
        { type: 'text', text }
      ],
      direct_gen_bm: true,
      agentId: 'creative-director',
      id: chatId,
      messages: [{ parts: [{ type: 'text', text }], id: msgId, role: 'user' }],
      trigger: 'submit-message'
    };
    // The response is an SSE stream; we only need the request accepted.
    const send = await apiWithAuth('/cowork/v3/chat', { method: 'POST', body });
    return { ...send, chatId };
  },

  async chatAssets(payload) {
    const chatId = payload && payload.chatId;
    if (!chatId) return { status: 400, ok: false, error: 'no chatId' };
    return apiWithAuth(`/assets?referenceType=chat&referenceId=${encodeURIComponent(chatId)}`);
  }
};

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    const handler = messageHandlers[msg.type];
    if (!handler) return false;
    Promise.resolve()
      .then(() => handler(msg.payload))
      .then((result) => sendResponse({ ok: true, result }))
      .catch((err) => sendResponse({ ok: false, error: String(err && err.message || err) }));
    return true; // keep the message channel open for the async response
  });
}
