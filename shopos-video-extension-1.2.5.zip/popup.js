// ShopOS Video Studio - popup logic

const $ = (id) => document.getElementById(id);
const el = {
  balance: $('balance'),
  loginTip: $('loginTip'),
  app: $('app'),
  prompt: $('prompt'),
  model: $('model'),
  count: $('count'),
  aspect: $('aspect'),
  resolution: $('resolution'),
  duration: $('duration'),
  audio: $('audio'),
  enhance: $('enhance'),
  mode: $('mode'),
  cost: $('cost'),
  generate: $('generate'),
  msg: $('msg'),
  results: $('results'),
  refresh: $('refresh'),
  loginReason: $('loginReason'),
  openLogin: $('openLogin'),
  refFiles: $('refFiles'),
  refList: $('refList'),
  refCaps: $('refCaps'),
  refClear: $('refClear')
};

const MEDIA_BASE = 'https://api-media.pro.shopos.ai';

// ---- reference assets state ----
let refSeq = 0;
let refs = []; // {id, file, name, kind:'image', size, status:'pending'|'uploading'|'done'|'error', assetUrl, previewUrl}

// verified against the live /models constraints:
//   seedance-2.5: 30 images (2.0 系 9 images)
// NOTE: video references are DISABLED — /models advertises maxRefVideos but the
// render pipeline silently drops them (verified 2026-10: snapshot.assets stays
// empty for video refs while image refs pass through). Credits still get charged.
const KNOWN_CAPS = {
  'seedance-2.5': { images: 30 },
  'seedance-2.0': { images: 9 },
  'seedance-2.0-fast': { images: 9 }
};

function modelCaps() {
  const m = currentModel();
  const known = (m && KNOWN_CAPS[m.id]) || { images: 9 };
  const c = (m && m.caps) || {};
  return {
    images: Number.isFinite(c.maxRefImages) ? c.maxRefImages : known.images
  };
}

function renderRefs() {
  const caps = modelCaps();
  const nImg = refs.filter((r) => r.kind === 'image').length;
  el.refCaps.textContent = `参考图上限：${nImg}/${caps.images}（视频参考不可用）`;

  if (!refs.length) {
    el.refList.innerHTML = '';
    return;
  }
  el.refList.innerHTML = refs.map((r) => {
    const stMap = {
      pending: '等待上传',
      uploading: '上传中…',
      done: '已上传',
      error: r.error ? '失败：' + r.error : '上传失败'
    };
    const st = `<span class="st ${r.status}">${stMap[r.status] || r.status}</span>`;
    const thumb = r.kind === 'image' && r.previewUrl
      ? `<img class="thumb" src="${r.previewUrl}" alt="" />`
      : `<div class="thumb icon">${r.kind === 'video' ? '🎬' : '🖼️'}</div>`;
    return `<div class="ref-item" data-id="${r.id}">
      ${thumb}
      <div class="info">
        <div class="name">${esc(r.name)}</div>
        ${st}
      </div>
      <button class="del" data-del="${r.id}" title="移除">✕</button>
    </div>`;
  }).join('');
}

el.refList.addEventListener('click', (e) => {
  const id = e.target && e.target.getAttribute && e.target.getAttribute('data-del');
  if (!id) return;
  refs = refs.filter((r) => String(r.id) !== String(id));
  renderRefs();
});

el.refClear.addEventListener('click', () => {
  refs.forEach((r) => r.previewUrl && URL.revokeObjectURL(r.previewUrl));
  refs = [];
  renderRefs();
});

el.refFiles.addEventListener('change', async () => {
  const files = Array.from(el.refFiles.files || []);
  el.refFiles.value = '';
  if (!files.length || !loggedIn) { if (!loggedIn) setMsg('请先登录后再上传参考素材', 'err'); return; }

  const caps = modelCaps();
  for (const file of files) {
    // video references are dropped by ShopOS's render pipeline (verified 2026-10)
    if ((file.type || '').startsWith('video/')) {
      setMsg('不支持视频参考：ShopOS 渲染端会忽略视频参考并照常扣积分，请改用参考图', 'err');
      continue;
    }
    const kind = 'image';
    const used = refs.filter((r) => r.kind === kind).length;
    if (used >= caps.images) {
      setMsg(`已达参考图上限（${caps.images} 个），多余的已忽略`, 'err');
      continue;
    }
    const ref = {
      id: ++refSeq,
      file,
      name: file.name,
      kind,
      size: file.size,
      status: 'pending',
      assetUrl: null,
      previewUrl: URL.createObjectURL(file)
    };
    refs.push(ref);
    renderRefs();
    uploadRef(ref);
  }
});

// ---- media service upload (reverse-engineered from app frontend) ----
async function authHeaders(force) {
  const res = await send('getAuthInfo', { force: !!force });
  if (!res.ok || !res.result || !res.result.jwt) {
    throw new Error(res.result && res.result.error ? res.result.error : '获取凭证失败');
  }
  const h = { Authorization: `Bearer ${res.result.jwt}` };
  if (res.result.wsId) h['x-workspace-id'] = res.result.wsId;
  return h;
}

async function uploadRef(ref) {
  ref.status = 'uploading';
  renderRefs();
  try {
    let headers = await authHeaders(false);
    const file = ref.file;
    const contentType = file.type || (ref.kind === 'video' ? 'video/mp4' : 'image/jpeg');

    // 1) register upload -> presigned url / multipart params
    let up = null;
    for (let attempt = 0; attempt < 2; attempt++) {
      const r = await fetch(`${MEDIA_BASE}/media/upload`, {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName: file.name, size: file.size, contentType })
      });
      if (r.status === 401 && attempt === 0) {
        headers = await authHeaders(true);
        continue;
      }
      if (!r.ok) throw new Error(`media/upload ${r.status}`);
      up = await r.json();
      break;
    }
    if (!up) throw new Error('media/upload failed');

    // 2) push bytes (simple PUT or multipart)
    if (up.uploadType === 'simple') {
      const put = await fetch(up.url, { method: 'PUT', body: file, headers: { 'Content-Type': contentType } });
      if (!put.ok) throw new Error(`PUT ${put.status}`);
    } else {
      const total = up.totalParts || 1;
      const gp = await fetch(`${MEDIA_BASE}/media/upload/multipart/get_part_urls`, {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: up.key, uploadId: up.uploadId, partNumbers: Array.from({ length: total }, (_, i) => i + 1) })
      });
      if (!gp.ok) throw new Error(`get_part_urls ${gp.status}`);
      const { urls } = await gp.json();
      const parts = [];
      for (let p = 1; p <= total; p++) {
        const start = (p - 1) * up.partSize;
        const blob = file.slice(start, Math.min(start + up.partSize, file.size));
        const pu = (urls || []).find((u) => u.partNumber === p);
        if (!pu) throw new Error(`missing part url ${p}`);
        const pr = await fetch(pu.url, { method: 'PUT', body: blob });
        if (!pr.ok) throw new Error(`part PUT ${pr.status}`);
        parts.push({ ETag: pr.headers.get('ETag'), PartNumber: p });
      }
      const cp = await fetch(`${MEDIA_BASE}/media/upload/multipart/complete`, {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: up.key, uploadId: up.uploadId, parts })
      });
      if (!cp.ok) throw new Error(`complete ${cp.status}`);
    }

    // 3) final url: images go through process-image, videos use cdnUrl directly
    let finalUrl = up.cdnUrl || null;
    if (ref.kind === 'image') {
      try {
        const pi = await fetch(`${MEDIA_BASE}/media/process-image`, {
          method: 'POST',
          headers: { ...headers, 'Content-Type': 'application/json' },
          body: JSON.stringify({ key: up.key })
        });
        if (pi.ok) {
          const d = await pi.json();
          finalUrl = (d.optimized && d.optimized.url) || (d.thumbnail && d.thumbnail.url) || finalUrl;
        }
      } catch (e) { /* fall back to cdnUrl */ }
    }
    if (!finalUrl) throw new Error('no cdn url');

    ref.assetUrl = finalUrl;
    ref.status = 'done';
  } catch (e) {
    ref.status = 'error';
    ref.error = String(e && e.message || e);
  }
  renderRefs();
}

async function waitRefsSettled() {
  // kick any pending uploads, wait until all settle
  refs.filter((r) => r.status === 'pending').forEach(uploadRef);
  const deadline = Date.now() + 5 * 60 * 1000;
  while (refs.some((r) => r.status === 'uploading' || r.status === 'pending')) {
    if (Date.now() > deadline) break;
    await new Promise((r) => setTimeout(r, 500));
  }
}

function uploadedAssets() {
  return refs
    .filter((r) => r.status === 'done' && r.assetUrl)
    .map((r) => ({ url: r.assetUrl, type: r.kind, role: 'reference' }));
}

// fallback when /models is unavailable
const FALLBACK_MODELS = [
  {
    id: 'seedance-2.0-fast', label: 'Seedance 2.0 Fast（便宜快速）',
    ar: ['16:9', '9:16', '1:1', '4:3', '3:4', '21:9', 'auto'],
    res: ['480p', '720p'],
    dur: ['4', '5', '6', '7', '8', '9', '10', '12', '15'],
    defaults: { aspectRatio: '16:9', resolution: '480p', duration: '4' }
  },
  {
    id: 'seedance-2.5', label: 'Seedance 2.5',
    ar: ['16:9', '9:16', '1:1', '4:3', '3:4', '21:9', 'auto'],
    res: ['480p', '720p', '1080p'],
    dur: ['4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '20', '22', '24', '26', '28', '30'],
    defaults: { aspectRatio: '16:9', resolution: '720p', duration: '8' }
  },
  {
    id: 'veo-3.1', label: 'Veo 3.1',
    ar: ['16:9', '9:16'],
    res: ['720p', '1080p'],
    dur: ['8'],
    defaults: { aspectRatio: '16:9', resolution: '720p', duration: '8' }
  },
  {
    id: 'kling-3.0', label: 'Kling 3.0',
    ar: ['16:9', '9:16', '1:1'],
    res: ['720p', '1080p'],
    dur: ['3', '4', '5', '6', '7', '8', '10', '15'],
    defaults: { aspectRatio: '16:9', resolution: '720p', duration: '8' }
  },
  {
    id: 'minimax-h3', label: 'MiniMax H3',
    ar: ['16:9', '9:16', '1:1', '4:3', '3:4', '21:9'],
    res: ['480p', '720p', '1080p'],
    dur: ['5', '6', '8', '10', '15'],
    defaults: { aspectRatio: '16:9', resolution: '720p', duration: '8' }
  }
];

let loggedIn = false;
let pollTimer = null;
let videoModels = FALLBACK_MODELS;

function send(type, payload) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (v) => { if (!settled) { settled = true; resolve(v); } };
    // hard cap so the UI can never hang forever
    const timer = setTimeout(() => done({ ok: false, error: '扩展响应超时（120s），请重开扩展重试' }), 120000);
    try {
      chrome.runtime.sendMessage({ type, payload }, (res) => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) {
          done({ ok: false, error: chrome.runtime.lastError.message });
        } else {
          done(res || { ok: false, error: 'no response' });
        }
      });
    } catch (e) {
      clearTimeout(timer);
      done({ ok: false, error: String(e && e.message || e) });
    }
  });
}

function setMsg(text, cls = '') {
  el.msg.textContent = text || '';
  el.msg.className = 'msg ' + cls;
}

function currentModel() {
  return videoModels.find((m) => m.id === el.model.value) || videoModels[0] || null;
}

function modelConfig() {
  return {
    aspectRatio: el.aspect.value,
    resolution: el.resolution.value,
    duration: el.duration.value,
    modelName: el.model.value,
    generateAudio: el.audio.value === 'on'
  };
}

function fillSelect(sel, values, chosen) {
  sel.innerHTML = values.map((v) => `<option value="${v}">${v}</option>`).join('');
  if (values.includes(chosen)) sel.value = chosen;
  else if (values.length) sel.value = values[0];
}

function rebuildModelOptions(keepCurrent = false) {
  const m = currentModel();
  if (!m) return;
  const prevAr = keepCurrent ? el.aspect.value : null;
  const prevRes = keepCurrent ? el.resolution.value : null;
  const prevDur = keepCurrent ? el.duration.value : null;
  const d = m.defaults || {};
  fillSelect(el.aspect, m.ar && m.ar.length ? m.ar : ['16:9'], keepCurrent ? prevAr : d.aspectRatio);
  fillSelect(el.resolution, m.res && m.res.length ? m.res : ['480p', '720p'], keepCurrent ? prevRes : (d.resolution || '480p'));
  fillSelect(el.duration, m.dur && m.dur.length ? m.dur : ['4', '8'], keepCurrent ? prevDur : String(d.duration || 4));
}

function saveSettings() {
  chrome.storage.local.set({
    settings: {
      prompt: el.prompt.value,
      model: el.model.value,
      count: el.count.value,
      aspect: el.aspect.value,
      resolution: el.resolution.value,
      duration: el.duration.value,
      audio: el.audio.value,
      enhance: el.enhance.checked,
      mode: el.mode.value
    }
  });
}

function storageGet(key) {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(key, (res) => resolve(res || {}));
    } catch (e) {
      resolve({});
    }
  });
}

function storageSet(obj) {
  return new Promise((resolve) => {
    try { chrome.storage.local.set(obj, () => resolve()); } catch (e) { resolve(); }
  });
}

async function loadSettings() {
  const store = await storageGet(null);
  let settings = store.settings || {};
  // one-time migration (v2): new defaults — enhance OFF, audio ON
  if (!store.settingsVer || store.settingsVer < 2) {
    settings.enhance = false;
    settings.audio = 'on';
    await storageSet({ settings, settingsVer: 2 });
  }
  if (settings.prompt) el.prompt.value = settings.prompt;
  if (settings.count) el.count.value = settings.count;
  if (settings.audio) el.audio.value = settings.audio;
  if (typeof settings.enhance === 'boolean') el.enhance.checked = settings.enhance;
  if (settings.mode) el.mode.value = settings.mode;
  return settings;
}

function applySavedSelections(settings) {
  if (!settings) return;
  if (settings.model && el.model.querySelector(`option[value="${settings.model}"]`)) el.model.value = settings.model;
  rebuildModelOptions(false);
  const m = currentModel();
  if (m) {
    if (settings.aspect && (m.ar || []).includes(settings.aspect)) el.aspect.value = settings.aspect;
    if (settings.resolution && (m.res || []).includes(settings.resolution)) el.resolution.value = settings.resolution;
    if (settings.duration && (m.dur || []).includes(settings.duration)) el.duration.value = settings.duration;
  }
}

async function refreshBalance() {
  const res = await send('balance');
  if (res.ok && res.result && res.result.ok) {
    const d = res.result.data;
    el.balance.textContent = `Credits ${d.total_credits}`;
  } else if (res.ok && res.result && res.result.status === 401) {
    el.balance.textContent = '未登录';
    loggedIn = false;
    el.loginTip.classList.remove('hidden');
    updateGenerateState();
  }
}

async function loadModels() {
  const res = await send('models');
  if (res.ok && res.result && res.result.ok) {
    const data = res.result.data || {};
    const v = data.video || {};
    const arr = Array.isArray(v) ? v : (v.models || []);
    const mapped = arr
      .map((m) => {
        const f = m.fields || {};
        const opt = (k) => ((f[k] && f[k].options) || []).map((o) => String(o.value));
        const c = m.constraints || {};
        return m.id ? {
          id: m.id,
          label: m.label || m.id,
          ar: opt('aspectRatio'),
          res: opt('resolution'),
          dur: opt('duration'),
          defaults: m.defaults || {},
          caps: {
            maxRefImages: typeof c.maxRefImages === 'number' ? c.maxRefImages : undefined
          }
        } : null;
      })
      .filter(Boolean);
    if (mapped.length) videoModels = mapped;
  }
  el.model.innerHTML = videoModels
    .map((m) => `<option value="${m.id}">${m.label}</option>`)
    .join('');
  renderRefs();
}

let costTimer = null;
function scheduleCost() {
  clearTimeout(costTimer);
  costTimer = setTimeout(updateCost, 400);
}

async function updateCost() {
  if (!loggedIn) return;
  if (el.mode.value === 'agent') {
    el.cost.innerHTML = '智能体模式 · <b>无预扣校验</b>（结算封顶）';
    return;
  }
  el.cost.textContent = '费用 …';
  const res = await send('cost', { modelConfig: modelConfig() });
  if (res.ok && res.result && res.result.ok) {
    const d = res.result.data;
    let n = null;
    if (typeof d === 'number') n = d;
    else if (d && typeof d === 'object') n = d.cost ?? d.credits ?? d.total ?? d.totalCredits ?? d.total_cost;
    el.cost.innerHTML = n != null ? `费用 <b>${n} credits</b> / 条` : '费用 –';
  } else {
    el.cost.textContent = '费用 –';
  }
}

function updateGenerateState() {
  el.generate.disabled = !loggedIn || el.prompt.value.trim().length === 0;
  el.generate.textContent = !loggedIn
    ? '请先登录 ShopOS'
    : (el.prompt.value.trim() ? `生成（${el.count.value} 条）` : '输入提示词后生成');
}

function badge(status) {
  const s = String(status || '').toLowerCase();
  const cls = ['completed', 'processing', 'pending', 'queued', 'running', 'failed', 'error']
    .find((k) => s.includes(k)) || 'processing';
  return `<span class="badge ${cls}">${status}</span>`;
}

function esc(s) {
  return String(s || '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

function renderResults(items) {
  if (!items || !items.length) {
    el.results.innerHTML = '<div class="meta">暂无生成记录</div>';
    return;
  }
  el.results.innerHTML = items.map((g) => {
    const url = g.url;
    const meta = [badge(g.status), g.source ? `<span class="badge">${esc(g.source)}</span>` : '', esc(g.modelName), esc(g.resolution), esc(g.aspectRatio), g.duration ? esc(String(g.duration)) + 's' : '', g.creditUsed != null ? esc(String(g.creditUsed)) + ' cr' : '']
      .filter(Boolean).join(' ');
    const media = url
      ? `<video src="${url}" controls preload="metadata"></video>`
      : '';
    const acts = url
      ? `<div class="acts"><a class="hl" href="${url}" target="_blank" rel="noreferrer">打开</a><a href="${url}" download="shopos-video.mp4">下载</a></div>`
      : '';
    return `<div class="item">
      <div class="meta">${meta}</div>
      ${media}
      <div class="p">${esc(g.prompt || '')}</div>
      ${acts}
    </div>`;
  }).join('');
}

function normalizeStudio(g) {
  const cfg = (g.snapshot && g.snapshot.modelConfig) || (g.payload && g.payload.modelConfig) || {};
  return {
    status: g.status,
    source: '直连',
    modelName: cfg.modelName,
    resolution: cfg.resolution,
    aspectRatio: cfg.aspectRatio,
    duration: cfg.duration,
    creditUsed: g.creditUsage ? g.creditUsage.used : null,
    url: (g.output && g.output.url) || '',
    prompt: (g.snapshot && (g.snapshot.finalPrompt || g.snapshot.prompt)) || (g.payload && g.payload.prompt) || ''
  };
}

function normalizeAgent(a) {
  const md = a.metadata || {};
  return {
    status: 'completed',
    source: '智能体',
    modelName: a.model,
    resolution: md.dimensions ? (md.dimensions.height >= 720 ? '720p+' : '480p') : '',
    aspectRatio: md.dimensions && md.dimensions.width ? (md.dimensions.width / md.dimensions.height > 1.2 ? '16:9' : (md.dimensions.width === md.dimensions.height ? '1:1' : '9:16')) : '',
    duration: md.duration ? Math.round(md.duration) : '',
    creditUsed: null,
    url: a.mediaUrl || '',
    prompt: md.referenceName === 'generateVideo' ? '（智能体 generateVideo 输出）' : '（智能体输出）'
  };
}

async function refreshResults() {
  const items = [];
  const { agentJobs } = await storageGet('agentJobs');
  const jobs = (agentJobs || []).slice(0, 4);
  if (jobs.length && loggedIn) {
    const assetLists = await Promise.all(jobs.map((j) => send('chatAssets', { chatId: j.chatId })));
    assetLists.forEach((r) => {
      if (r.ok && r.result && r.result.ok) {
        const d = r.result.data;
        const arr = (d && d.data && d.data.assets) || (Array.isArray(d) ? d : (d && d.assets) || []);
        arr.filter((a) => a.assetType === 'video' && a.mediaUrl).forEach((a) => items.push(normalizeAgent(a)));
      }
    });
  }
  const res = await send('generations', { page: 1, size: 8 });
  if (res.ok && res.result && res.result.ok) {
    const d = res.result.data;
    const list = Array.isArray(d) ? d : (d.data || d.items || []);
    list.forEach((g) => items.push(normalizeStudio(g)));
  }
  renderResults(items);
  const hasActive = items.some((g) => !['completed', 'failed', 'error', 'cancelled'].includes(String(g.status).toLowerCase()));
  if (hasActive && loggedIn) {
    clearTimeout(pollTimer);
    pollTimer = setTimeout(refreshResults, 5000);
  }
}

async function boot() {
  el.model.innerHTML = FALLBACK_MODELS.map((m) => `<option value="${m.id}">${m.label}</option>`).join('');
  const settings = await loadSettings();
  renderRefs();

  const st = await send('status');
  if (st.ok && st.result && st.result.loggedIn) {
    loggedIn = true;
    el.loginTip.classList.add('hidden');
    el.balance.textContent = '…';
    await loadModels();
    applySavedSelections(settings);
    await Promise.all([refreshBalance(), refreshResults()]);
    updateCost();
  } else {
    loggedIn = false;
    el.balance.textContent = '未登录';
    const r = st.result || {};
    let reason;
    if (r.reason === 'no-session') {
      reason = '这个浏览器里确实没有 ShopOS 会话：请点下方按钮，在弹出的页面里登录 app.shopos.ai（其他浏览器/App 里登录无效）。登录后回到扩展会自动识别。';
    } else if (r.reason === 'no-tab') {
      reason = '无法打开 ShopOS 页面做登录校验（浏览器不支持页面注入）。请手动打开 app.shopos.ai 并保持已登录，再刷新本扩展。';
    } else {
      reason = 'ShopOS 登录服务不可达：请检查网络（能否正常打开 app.shopos.ai），或稍后重试。';
    }
    el.loginReason.textContent = reason;
    el.loginTip.classList.remove('hidden');
    rebuildModelOptions(false);
  }
  updateGenerateState();
}

el.openLogin.addEventListener('click', () => {
  try { chrome.tabs.create({ url: 'https://app.shopos.ai/sign-in' }); } catch (e) {}
});

// events
['change', 'input'].forEach((ev) => {
  [el.count, el.audio].forEach((c) =>
    c.addEventListener(ev, () => { saveSettings(); scheduleCost(); updateGenerateState(); })
  );
});
el.model.addEventListener('change', () => { rebuildModelOptions(false); saveSettings(); scheduleCost(); renderRefs(); });
[el.aspect, el.resolution, el.duration].forEach((c) =>
  c.addEventListener('change', () => { saveSettings(); scheduleCost(); })
);
el.enhance.addEventListener('change', () => { saveSettings(); scheduleCost(); });
el.mode.addEventListener('change', () => { saveSettings(); updateCost(); });
el.prompt.addEventListener('input', () => { saveSettings(); updateGenerateState(); });
el.refresh.addEventListener('click', refreshResults);

el.generate.addEventListener('click', async () => {
  const prompt = el.prompt.value.trim();
  if (!prompt || !loggedIn) return;
  el.generate.disabled = true;

  // make sure all reference assets finish uploading first
  if (refs.some((r) => r.status !== 'done' && r.status !== 'error')) {
    setMsg('上传参考素材中…');
    await waitRefsSettled();
  }
  const assets = uploadedAssets();
  const failed = refs.filter((r) => r.status === 'error').length;

  if (el.mode.value === 'agent') {
    setMsg('智能体管道提交中…');
    const dur = el.duration.value;
    const text = `使用 ${el.model.value} 模型生成一个 ${dur} 秒的视频，${el.aspect.value}，${el.resolution.value}，${el.audio.value === 'on' ? '有声音' : '无声音'}。内容：${prompt}。直接提交生成，无需确认。`;
    const res = await send('agentGenerate', {
      text,
      referenceUrls: assets.map((a) => a.url),
      generationConfig: { mode: 'video', modelId: el.model.value, modelConfig: { modelName: el.model.value, aspectRatio: el.aspect.value, resolution: el.resolution.value } }
    });
    if (res.ok && res.result && res.result.ok) {
      const chatId = res.result.chatId;
      setMsg(`已提交到智能体管道（参考 ${assets.length} 项${failed ? `，${failed} 项上传失败已跳过` : ''}），生成中…`, 'ok');
      el.prompt.value = '';
      saveSettings();
      updateGenerateState();
      if (chatId) {
        const { agentJobs } = await storageGet('agentJobs');
        const jobs = [{ chatId, ts: Date.now() }, ...(agentJobs || [])].slice(0, 6);
        await storageSet({ agentJobs: jobs });
        pollAgentJob(chatId, 60);
      }
      refreshBalance();
      refreshResults();
    } else {
      const detail = res.error || (res.result && (res.result.error || (res.result.data && JSON.stringify(res.result.data).slice(0, 200)))) || '未知错误';
      setMsg(`提交失败：${detail}`, 'err');
      el.generate.disabled = false;
    }
    return;
  }

  setMsg('提交中…');
  const res = await send('generate', {
    prompt,
    modelConfig: modelConfig(),
    generationCount: parseInt(el.count.value, 10) || 1,
    enhancePrompt: el.enhance.checked,
    uploadedAssets: assets
  });
  if (res.ok && res.result && res.result.ok) {
    setMsg(`已提交（参考 ${assets.length} 项${failed ? `，${failed} 项上传失败已跳过` : ''}），等待生成完成…`, 'ok');
    el.prompt.value = '';
    saveSettings();
    updateGenerateState();
    refreshBalance();
    refreshResults();
  } else {
    const detail = res.error || (res.result && (res.result.error || (res.result.data && JSON.stringify(res.result.data).slice(0, 200)))) || '未知错误';
    setMsg(`提交失败：${detail}`, 'err');
    el.generate.disabled = false;
  }
});

function pollAgentJob(chatId, triesLeft) {
  if (!triesLeft) return;
  clearTimeout(pollTimer);
  pollTimer = setTimeout(async () => {
    await refreshResults();
    const { agentJobs } = await storageGet('agentJobs');
    const job = (agentJobs || []).find((j) => j.chatId === chatId);
    if (!job) return;
    const r = await send('chatAssets', { chatId });
    const d = r.ok && r.result && r.result.ok ? r.result.data : null;
    const arr = (d && d.data && d.data.assets) || (Array.isArray(d) ? d : (d && d.assets) || []);
    const hasVideo = arr.some((a) => a.assetType === 'video' && a.mediaUrl);
    if (hasVideo) {
      setMsg('智能体任务已完成', 'ok');
      refreshBalance();
    } else {
      pollAgentJob(chatId, triesLeft - 1);
    }
  }, 6000);
}

boot();
