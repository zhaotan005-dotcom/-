// ShopOS Video Studio - background (service_worker for Chromium / event page for Firefox Android)
// Auth: Clerk cookies (from the user's normal app.shopos.ai login) -> mint short-lived JWT -> call api.pro.shopos.ai

const CLERK_API = 'https://clerk.app.shopos.ai/v1';
const CLERK_QS = '__clerk_api_version=2026-05-12&_clerk_js_version=6.38.0';
const API_BASE = 'https://api.pro.shopos.ai';

// The personality field is DELETED entirely (empty soul.md) — obedience
// instructions live in each submission message instead. After writing we
// re-read and verify, so "done" means it really took effect.

function findSoulConfigs(data) {
  // The list response shape is not publicly stable; walk any JSON structure and
  // collect objects that carry a soulMd string plus an id.
  const found = [];
  const seen = new Set();
  (function walk(v, depth) {
    if (!v || typeof v !== 'object' || depth > 6 || seen.has(v)) return;
    seen.add(v);
    if (Array.isArray(v)) { v.forEach((x) => walk(x, depth + 1)); return; }
    if (typeof v.soulMd === 'string' && (v.id || v.configId)) found.push(v);
    Object.keys(v).forEach((k) => walk(v[k], depth + 1));
  })(data, 0);
  return found;
}

function pickSoulConfig(configs) {
  // Multiple agents can exist in one workspace — pick the creative-director
  // config by exact identity fields first, then by name, never by accident.
  return configs.find((c) => c.agentId === 'creative-director' || c.slug === 'creative-director' || c.key === 'creative-director')
    || configs.find((c) => JSON.stringify(c).toLowerCase().includes('"agentid":"creative-director"') || JSON.stringify(c).toLowerCase().includes('monica'))
    || configs[0];
}

// token cache (JWT lives ~60s; refresh at 45s)
let cachedToken = null; // { jwt, wsId, ts }

// Live state of agent submissions, parsed from their SSE streams.
// chatId -> { wsId, done, videoUrl, lastEvent, startedAt }
const agentStreams = new Map();

async function readAgentStream(chatId, res, wsId) {
  const st = { wsId, chatId, done: false, videoUrl: null, lastEvent: '', answer: '', error: '', startedAt: Date.now() };
  // 清理 3 小时前已结束的流状态，避免 Map 无限增长
  for (const [k, v] of agentStreams) {
    if (v.done && Date.now() - v.startedAt > 3 * 3600 * 1000) agentStreams.delete(k);
  }
  agentStreams.set(chatId, st);
  // 保活：MV3 服务线程空闲会被回收，流读到一半就会被掐断；定期调一个无害 API 续命
  const keepAlive = setInterval(() => { try { chrome.runtime.getPlatformInfo(() => {}); } catch (e) {} }, 20000);
  let lineBuf = '';
  let tail = '';
  // 文本片段按 id 累加（AI SDK 的 text-delta 流），最终回复 = 最后一个非空片段
  const parts = new Map();
  let lastPartId = null;

  const handleData = (raw) => {
    raw = String(raw || '').trim();
    if (!raw || raw === '[DONE]') return;
    let j;
    try { j = JSON.parse(raw); } catch (e) { return; }
    if (!j || typeof j !== 'object') return;
    const type = String(j.type || j.eventName || j.step || '');
    if (type) st.lastEvent = type.slice(0, 80);

    // 错误信息（流内 error 事件 / 工具报错）
    const errText = j.errorText
      || (type === 'error' && (typeof j.error === 'string' ? j.error : (j.error && j.error.message)))
      || (j.error && typeof j.error === 'string' ? j.error : '');
    if (errText) st.error = String(errText).slice(0, 800);

    if (type === 'text-delta' && typeof j.delta === 'string') {
      const id = String(j.id != null ? j.id : '0');
      parts.set(id, (parts.get(id) || '') + j.delta);
      lastPartId = id;
      const t = (parts.get(lastPartId) || '').trim();
      if (t) st.answer = t.slice(0, 1500);
      return;
    }
    if (type === 'text-start') {
      lastPartId = String(j.id != null ? j.id : '0');
      if (!parts.has(lastPartId)) parts.set(lastPartId, '');
      return;
    }
    // 兼容其他形态：整段 text 直接给出
    const t = (typeof j.text === 'string' && j.text)
      || (j.data && typeof j.data.text === 'string' && j.data.text)
      || (j.delta && typeof j.delta.text === 'string' && j.delta.text)
      || '';
    if (t && type !== 'text-delta') {
      const tt = String(t).trim();
      if (tt) st.answer = tt.slice(0, 1500);
    }
  };

  try {
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      const chunk = dec.decode(value, { stream: true });

      // 1) 最终视频：cdn mp4 直链（滚动窗口，防止跨 chunk 丢失）
      tail = (tail + chunk).slice(-6000);
      const mp4s = tail.match(/https:\/\/cdn\.pro\.shopos\.ai\/[^"\\\s]+\.mp4/g);
      if (mp4s && mp4s.length) {
        const u = mp4s[mp4s.length - 1];
        if (st.videoUrl !== u) {
          st.videoUrl = u;
          try { chrome.storage.local.set({ ['joburl:' + wsId + ':' + chatId]: u }); } catch (e) {}
        }
      }

      // 2) 逐行增量解析 SSE（每行只解析一次）
      lineBuf += chunk;
      const lines = lineBuf.split('\n');
      lineBuf = lines.pop();
      for (const ln of lines) {
        if (ln.indexOf('data:') === 0) handleData(ln.slice(5));
      }
    }
    if (lineBuf.indexOf('data:') === 0) handleData(lineBuf.slice(5));
  } catch (e) {
    // 流被掐断（断网 / SW 被回收）：视频可能仍会在站点侧产出，可稍后从资产里找回
    st.aborted = true;
  }
  clearInterval(keepAlive);
  st.done = true;
  if (!st.aborted) {
    const w = { ['jobdone:' + wsId + ':' + chatId]: 1 };
    // 流正常结束却没有视频：把智能体的回复落盘，弹窗重开后仍能显示失败原因
    if (!st.videoUrl) w['jobfail:' + wsId + ':' + chatId] = (st.answer || st.error || '').slice(0, 1500);
    try { chrome.storage.local.set(w); } catch (e) {}
  }
  agentStreams.set(chatId, st);
}

function b64urlDecode(s) {
  const pad = s.length % 4 === 0 ? '' : '='.repeat(4 - (s.length % 4));
  const b64 = s.replace(/-/g, '+').replace(/_/g, '/') + pad;
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}

function decodeJwtPayload(jwt) {
  try {
    return JSON.parse(b64urlDecode(jwt.split('.')[1]));
  } catch (e) {
    return null;
  }
}

async function clerkGetClient() {
  const res = await fetch(`${CLERK_API}/client?${CLERK_QS}`, {
    method: 'GET',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' }
  });
  if (!res.ok) throw new Error(`Clerk client ${res.status}`);
  return res.json();
}

async function clerkMintToken(sessionId) {
  const res = await fetch(`${CLERK_API}/client/sessions/${sessionId}/tokens?${CLERK_QS}`, {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' }
  });
  if (!res.ok) {
    let detail = '';
    try {
      const j = await res.json();
      detail = (j.errors && j.errors[0] && (j.errors[0].message || j.errors[0].code)) || JSON.stringify(j).slice(0, 120);
    } catch (e) { detail = ''; }
    const err = new Error(`Clerk token ${res.status}${detail ? '：' + detail : ''}`);
    err.code = 'CLERK_TOKEN_' + res.status;
    throw err;
  }
  return res.json();
}

// Mint a JWT from inside a real app.shopos.ai tab. Mobile browsers (Firefox
// Android dFPI / Kiwi cookie rules) may partition or block the service
// worker's access to Clerk's cross-site cookies, but a normal page on
// app.shopos.ai always sees them — same as the website itself.
function tabAuthFunc(clerkApi, qs) {
  return (async () => {
    try {
      const res = await fetch(`${clerkApi}/client?${qs}`, {
        method: 'GET',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' }
      });
      if (!res.ok) throw new Error('Clerk client ' + res.status);
      const j = await res.json();
      const body = j.response || j.client || j;
      const sessions = body.sessions || [];
      const active = sessions.find((s) => s.status === 'active') || sessions[0];
      if (!active) {
        const err = new Error('NOT_LOGGED_IN');
        err.code = 'NOT_LOGGED_IN';
        throw err;
      }
      const t = await fetch(`${clerkApi}/client/sessions/${active.id}/tokens?${qs}`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' }
      });
      if (!t.ok) throw new Error('Clerk token ' + t.status);
      const tj = await t.json();
      if (!tj.jwt) throw new Error('NO_JWT');
      return { jwt: tj.jwt };
    } catch (e) {
      return { error: String(e && e.message || e), code: e.code || null };
    }
  })();
}

function tabWaitComplete(tabId, timeout) {
  return new Promise((resolve) => {
    const t0 = Date.now();
    const check = () => {
      try {
        chrome.tabs.get(tabId, (tab) => {
          if (chrome.runtime.lastError) return resolve(false);
          if (tab && tab.status === 'complete') return resolve(true);
          if (Date.now() - t0 > timeout) return resolve(false);
          setTimeout(check, 500);
        });
      } catch (e) { resolve(false); }
    };
    check();
  });
}

function withTimeout(promise, ms, tag) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => {
      const err = new Error(tag + ' timeout');
      err.code = 'AUTH_TIMEOUT';
      reject(err);
    }, ms))
  ]);
}

async function authViaTab() {
  if (typeof chrome === 'undefined' || !chrome.scripting || !chrome.tabs) {
    const err = new Error('NO_SCRIPTING_API');
    err.code = 'NO_SCRIPTING_API';
    throw err;
  }
  const url = 'https://app.shopos.ai/home';
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: 'https://app.shopos.ai/*' }); } catch (e) { tabs = []; }
  let tabId = null;
  if (tabs && tabs.length) {
    tabId = tabs[0].id;
  } else {
    const t = await chrome.tabs.create({ url, active: false });
    tabId = t.id;
    const ok = await tabWaitComplete(tabId, 10000);
    if (!ok) {
      // background tabs may not load on mobile; bring it to front once
      try { await chrome.tabs.update(tabId, { active: true }); } catch (e) {}
      await tabWaitComplete(tabId, 15000);
    }
  }
  if (!tabId) throw new Error('NO_TAB');
  const results = await withTimeout(chrome.scripting.executeScript({
    target: { tabId },
    world: 'ISOLATED',
    func: tabAuthFunc,
    args: [CLERK_API, CLERK_QS]
  }), 25000, 'inject');
  const r = results && results[0] && results[0].result;
  if (!r) throw new Error('TAB_AUTH_EMPTY');
  if (r.error) {
    const err = new Error(r.error);
    err.code = r.code || null;
    throw err;
  }
  return r.jwt;
}

// Returns { jwt, wsId, ts }
// Concurrent callers (e.g. several reference images uploading at once, or the
// popup's parallel boot requests after the cache expired) share ONE mint —
// otherwise each fires its own Clerk requests and, on the tab fallback path,
// can each open its own app.shopos.ai tab.
let authInflight = null;
async function getAuth(force = false) {
  if (!force && cachedToken) {
    const age = (Date.now() - cachedToken.ts) / 1000;
    if (age < 45) return cachedToken;
  }
  if (!authInflight) {
    authInflight = mintAuth().finally(() => { authInflight = null; });
  }
  return authInflight;
}

async function mintAuth() {
  let jwt = null;
  let swErr = null;
  // fast path: service worker fetch (works on desktop)
  try {
    jwt = await (async () => {
      const client = await clerkGetClient();
      const body = client.response || client.client || client;
      const sessions = body.sessions || [];
      if (!sessions.length) {
        const err = new Error('NOT_LOGGED_IN');
        err.code = 'NOT_LOGGED_IN';
        throw err;
      }
      // 换号后可能残留失效会话：active 优先，逐个尝试铸 token
      const ordered = [...sessions.filter((s) => s.status === 'active'), ...sessions.filter((s) => s.status !== 'active')];
      let lastErr = null;
      for (const s of ordered) {
        try {
          const tokRes = await clerkMintToken(s.id);
          if (tokRes.jwt) return tokRes.jwt;
        } catch (e) { lastErr = e; }
      }
      throw lastErr || new Error('NO_JWT');
    })();
  } catch (e) {
    swErr = e;
  }
  // fallback: mint inside an app.shopos.ai tab (works on mobile)
  if (!jwt) {
    try {
      jwt = await authViaTab();
    } catch (e) {
      if (e.code === 'NOT_LOGGED_IN') throw e;
      throw (swErr || e);
    }
  }
  cachedToken = { jwt, wsId: decodeJwtPayload(jwt)?.o?.id || null, ts: Date.now() };
  return cachedToken;
}

async function apiCall(path, { method = 'GET', body = null, auth, noBody = false } = {}) {
  const headers = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${auth.jwt}`
  };
  if (auth.wsId) headers['x-workspace-id'] = auth.wsId;
  const fetchOnce = () => Promise.race([
    fetch(`${API_BASE}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : null
    }),
    new Promise((_, reject) => setTimeout(() => reject(new Error('request timeout (60s)')), 60000))
  ]);
  const res = await fetchOnce();
  // noBody: for SSE-stream endpoints (e.g. /cowork/v3/chat) the response body
  // stays open for the whole agent run — reading it would block for minutes.
  // HTTP status alone tells us the job was accepted; only read the body on errors.
  let data = null;
  if (!noBody || !res.ok) {
    const text = await res.text();
    try { data = text ? JSON.parse(text) : null; } catch (e) { data = { raw: text }; }
  }
  return { status: res.status, ok: res.ok, data };
}

async function apiWithAuth(path, opts = {}) {
  let auth;
  try {
    auth = await getAuth();
  } catch (e) {
    return { status: 401, ok: false, error: e.message, code: e.code || null };
  }
  let r = await apiCall(path, { ...opts, auth });
  if (r.status === 401) {
    try {
      auth = await getAuth(true);
      r = await apiCall(path, { ...opts, auth });
    } catch (e) {
      return { status: 401, ok: false, error: e.message, code: e.code || null };
    }
  }
  return r;
}

const messageHandlers = {
  async status() {
    try {
      const auth = await getAuth();
      return { loggedIn: true, wsId: auth.wsId };
    } catch (e) {
      // With the tab-based fallback, NOT_LOGGED_IN means the user truly has
      // no ShopOS session in this browser (checked inside a real app tab).
      const code = e.code || null;
      let reason = 'clerk-unreachable';
      if (code === 'NOT_LOGGED_IN') reason = 'no-session';
      else if (code === 'NO_SCRIPTING_API' || code === 'NO_TAB') reason = 'no-tab';
      return { loggedIn: false, error: String(e && e.message || e), code, reason };
    }
  },

  async balance() {
    return apiWithAuth('/credits/balance');
  },

  // current account identity — lets the popup show which account is in use
  async profile() {
    return apiWithAuth('/users/profile');
  },

  async models() {
    return apiWithAuth('/cowork/creative-studio/models?frames=1');
  },

  // soul.md toggle: report whether the direct-execution override is installed
  async agentSoulStatus() {
    const r = await apiWithAuth('/cowork/agent-configs');
    if (!r.ok) return { ok: false, error: 'HTTP ' + r.status };
    const configs = findSoulConfigs(r.data);
    if (!configs.length) return { ok: true, found: false };
    const target = pickSoulConfig(configs);
    return {
      ok: true,
      found: true,
      id: target.id || target.configId,
      // verified-empty means the personality was really deleted
      enabled: String(target.soulMd || '').trim() === '',
      soulMd: String(target.soulMd || ''),
      soulMdLen: String(target.soulMd || '').length
    };
  },

  // soul.md toggle: install or remove the direct-execution override block
  async agentSoulSet(payload) {
    const enable = !!(payload && payload.enable);
    const r = await apiWithAuth('/cowork/agent-configs');
    if (!r.ok) return { ok: false, error: 'HTTP ' + r.status };
    const configs = findSoulConfigs(r.data);
    if (!configs.length) return { ok: false, error: '未找到含 soulMd 的智能体配置' };
    const target = pickSoulConfig(configs);
    const id = target.id || target.configId;
    // enable = delete the personality (empty soul.md); the submission message
    // carries the obedience instructions instead
    const soul = '';
    const put = await apiWithAuth('/cowork/agent-configs/' + encodeURIComponent(id), {
      method: 'PATCH',
      body: { soulMd: soul }
    });
    if (!put.ok) return { ok: false, error: 'HTTP ' + put.status, data: put.data };
    return { ok: true, enabled: enable };
  },

  // Disable every skill attached to the agent — zero interference while
  // generating. Idempotent: only patches skills that are still enabled.
  async skillsOff() {
    const r = await apiWithAuth('/cowork/skills/workspace?page=1&pageSize=100&agentScope=creative-director');
    if (!r.ok) return { ok: false, error: 'HTTP ' + r.status };
    let items = [];
    try {
      items = (r.data && (r.data.items || (r.data.data && r.data.data.items))) || [];
    } catch (e) { items = []; }
    if (!Array.isArray(items)) items = [];
    const results = [];
    for (const s of items) {
      if (!s || !s.id || s.enabled === false) continue;
      const p = await apiWithAuth('/cowork/skills/' + encodeURIComponent(s.id), {
        method: 'PATCH',
        body: { enabled: false, agentScopes: [] }
      });
      results.push({ name: s.name, ok: p.ok });
    }
    return { ok: true, disabled: results.filter((x) => x.ok).length, total: results.length };
  },

  // Popup does the media uploads itself (files never travel through messaging);
  // it only needs the short-lived JWT + workspace id minted here.
  async getAuthInfo(payload) {
    try {
      const auth = await getAuth(!!(payload && payload.force));
      return { jwt: auth.jwt, wsId: auth.wsId };
    } catch (e) {
      return { error: String(e && e.message || e), code: e.code || null };
    }
  },

  async generations(payload) {
    const page = (payload && payload.page) || 1;
    const size = (payload && payload.size) || 10;
    return apiWithAuth(`/cowork/creative-studio/generations/me?page=${page}&size=${size}`);
  },

  // Agent-pipeline mode: create a chat and let the server-side agent run the
  // videoDirector/generateVideo tool. Billing is settled afterwards and clamped
  // to the available balance (can exceed balance as long as balance > 0).
  async agentGenerate(payload) {
    let text = payload.text;
    if (!text) return { status: 400, ok: false, error: 'empty text' };
    // Chat attachment schema is not publicly stable; pass reference URLs inline
    // so the agent's generateVideo tool can ingest them from the message body.
    if (Array.isArray(payload.referenceUrls) && payload.referenceUrls.length) {
      text += '\n\n参考素材（生成时直接使用这些链接）：\n' + payload.referenceUrls.map((u, i) => `${i + 1}. ${u}`).join('\n');
    }
    const create = await apiWithAuth('/cowork/chats', { method: 'POST', body: { title: 'New chat', version: 'v3' } });
    if (!create.ok) return create;
    const chatId = (create.data && (create.data.id || (create.data.data && create.data.data.id)));
    if (!chatId) return { status: 500, ok: false, error: 'no chat id', data: create.data };

    const nanoidAlphabet = 'useandom-26T198340PX75pxJACKVERYMINDBUSHWOLFGQZbfghjklqvwyzrict';
    let msgId = '';
    for (let i = 0; i < 21; i++) msgId += nanoidAlphabet[Math.floor(Math.random() * nanoidAlphabet.length)];

    const body = {
      chat_id: chatId,
      version: 'v3',
      timezone: 'UTC',
      content: [
        { type: 'generation_config', data: payload.generationConfig || { mode: 'image', modelId: 'gemini-nano-banana-2.1', modelConfig: { modelName: 'gemini-nano-banana-2.1', aspectRatio: '1:1', resolution: '2K' } } },
        { type: 'text', text }
      ],
      direct_gen_bm: true,
      agentId: 'creative-director',
      id: chatId,
      messages: [{ parts: [{ type: 'text', text }], id: msgId, role: 'user' }],
      trigger: 'submit-message'
    };
    // The response is an SSE stream that carries the agent's live progress and
    // the final video URL. Read it in the background; the popup polls the
    // parsed state via agentJobState instead of guessing.
    try {
      let auth = await getAuth();
      const doFetch = (a) => fetch(`${API_BASE}/cowork/v3/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${a.jwt}`,
          ...(a.wsId ? { 'x-workspace-id': a.wsId } : {})
        },
        body: JSON.stringify(body)
      });
      let res = await doFetch(auth);
      if (res.status === 401) {
        auth = await getAuth(true);
        res = await doFetch(auth);
      }
      if (!res.ok) {
        const t = await res.text();
        let data = null; try { data = JSON.parse(t); } catch (e) { data = { raw: t }; }
        return { status: res.status, ok: false, error: 'HTTP ' + res.status, data, chatId };
      }
      readAgentStream(chatId, res, auth.wsId);
      return { status: res.status, ok: true, data: { accepted: true }, chatId };
    } catch (e) {
      return { status: 500, ok: false, error: String(e && e.message || e), chatId };
    }
  },

  // Live state of an agent submission (parsed from its SSE stream)
  async agentJobState(payload) {
    const chatId = payload && payload.chatId;
    let wsId = null;
    try {
      const a = await getAuth();
      wsId = a.wsId;
    } catch (e) { return { ok: true, found: false }; }
    const st = chatId && agentStreams.get(chatId);
    if (st && st.wsId === wsId) {
      return {
        ok: true,
        found: true,
        done: st.done,
        aborted: !!st.aborted,
        videoUrl: st.videoUrl,
        lastEvent: st.lastEvent,
        answer: st.answer || null,
        error: st.error || null,
        ageSec: Math.round((Date.now() - st.startedAt) / 1000)
      };
    }
    // SW was restarted and the in-memory stream state is gone — fall back to
    // the persisted captures, otherwise a finished job would spin forever.
    if (chatId && wsId) {
      try {
        const kUrl = 'joburl:' + wsId + ':' + chatId;
        const kDone = 'jobdone:' + wsId + ':' + chatId;
        const kFail = 'jobfail:' + wsId + ':' + chatId;
        const keys = await chrome.storage.local.get([kUrl, kDone, kFail]);
        if (keys[kUrl] || keys[kDone]) {
          return {
            ok: true,
            found: true,
            done: !!keys[kDone],
            videoUrl: keys[kUrl] || null,
            answer: keys[kFail] || null,
            lastEvent: '',
            ageSec: 0
          };
        }
      } catch (e) { /* storage unavailable */ }
    }
    return { ok: true, found: false };
  },

  async chatAssets(payload) {
    const chatId = payload && payload.chatId;
    if (!chatId) return { status: 400, ok: false, error: 'no chatId' };
    return apiWithAuth(`/assets?referenceType=chat&referenceId=${encodeURIComponent(chatId)}`);
  },

  // Best-effort: fetch the agent's last text reply for a chat (used as the
  // "why it didn't generate" reason when a job ends without a video).
  async chatReply(payload) {
    const chatId = payload && payload.chatId;
    if (!chatId) return { ok: false };
    const paths = [
      `/cowork/chats/${encodeURIComponent(chatId)}/messages`,
      `/cowork/v3/chats/${encodeURIComponent(chatId)}/messages`,
      `/cowork/chats/${encodeURIComponent(chatId)}`
    ];
    try {
      const a = await getAuth();
      for (const p of paths) {
        try {
          const r = await fetch(`${API_BASE}${p}`, {
            headers: {
              Authorization: `Bearer ${a.jwt}`,
              ...(a.wsId ? { 'x-workspace-id': a.wsId } : {})
            }
          });
          if (!r.ok) continue;
          const d = await r.json();
          const msgs = Array.isArray(d) ? d : ((d && (d.data || d.messages || (d.data && d.data.messages))) || []);
          let text = '';
          if (Array.isArray(msgs)) {
            for (let i = msgs.length - 1; i >= 0; i--) {
              const m = msgs[i] || {};
              const role = String(m.role || m.sender || '');
              const t = (typeof m.text === 'string' && m.text)
                || (typeof m.content === 'string' && m.content)
                || (Array.isArray(m.parts) ? m.parts.filter((x) => x && x.type === 'text').map((x) => x.text || '').join(' ') : '');
              if (t && role.toLowerCase().includes('assist')) { text = String(t); break; }
            }
          }
          if (!text && d) {
            const m2 = JSON.stringify(d).match(/"role"\s*:\s*"[^"]*assist[^"]*"[^}]*?"text"\s*:\s*"([\s\S]{0,300}?)"/i);
            if (m2) text = m2[1];
          }
          if (text) return { ok: true, text: text.slice(0, 300) };
        } catch (e) { /* try next path */ }
      }
    } catch (e) { /* auth unavailable */ }
    return { ok: false };
  }
};

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    const handler = messageHandlers[msg.type];
    if (!handler) return false;
    Promise.resolve()
      .then(() => handler(msg.payload))
      .then((result) => sendResponse({ ok: true, result }))
      .catch((err) => sendResponse({ ok: false, error: String(err && err.message || err) }));
    return true; // keep the message channel open for the async response
  });
}
