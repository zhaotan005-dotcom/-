/*
 * Direct Gen v3.1.0 — engine (页面侧引擎, isolated world)
 * 架构: popup(ShopOS 弹窗 UI) <-> chrome.runtime.onMessage <-> engine(本文件)
 * - fetch 由 engine 在页面同源上下文发起, 自动带登录 cookie, 无密钥
 * - popup 关闭后任务轮询照常进行, 重开 popup 拉取最新状态
 * - 站点限制: /api/estudio 507 故障 -> 全部走 /api/cut 管线; 免费版素材上传配额 0,
 *   参考图片走 /api/cut/{pid}/referencias (JPG/PNG/WEBP) 不占配额 (实测可用)
 */
(() => {
  if (window.__dgEngine) return;
  window.__dgEngine = true;

  const S = {
    catalog: null, models: [], projects: [],
    projSel: null, // 永远是真实项目 pid (默认项目自动建好, localStorage 记住复用)
    projOk: null,  // 最近一次验证过的 pid (避免每次估价都先查项目存在性)
    modelId: null, name: '', prompt: '',
    params: { duration: 3, resolution: null, aspect: null, audio: false },
    refs: {},     // campo -> [{kind:'ref'|'ai', id, label, status, error, thumb, file, campo}]
    entMeta: {},  // campo -> {base, plural, max}
    estFields: {}, // name -> {requerido, options:[{id,nombre}], value}
    estCache: {},
    balance: null, cost: null, estTimer: null,
    jobs: [],
    recent: [], logs: [],
    saved: null, // localStorage 恢复用, 消费一次后置 null
  };

  const LS = 'dg_v3';
  const TIPOS = ['imagen', 'imagenes', 'video', 'videos', 'audio', 'audios'];
  const BASE = { imagen: 'imagen', imagenes: 'imagen', video: 'video', videos: 'video', audio: 'audio', audios: 'audio' };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const log = (msg, cls) => { S.logs.push({ t: Date.now(), msg, cls: cls || '' }); if (S.logs.length > 200) S.logs.shift(); };
  const J = (r) => r.text().then((t) => { try { return JSON.parse(t); } catch (_) { return { _raw: t }; } });

  const API = {
    async catalogo() {
      const r = await fetch('/api/cut/generar/catalogo', { credentials: 'include' });
      if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + (await r.text()).slice(0, 80));
      return J(r);
    },
    async estilos(fuente) {
      const r = await fetch('/api/cut/generar/estilos?fuente=' + encodeURIComponent(fuente), { credentials: 'include' });
      if (!r.ok) throw new Error('estilos ' + r.status);
      return J(r);
    },
    async crearProyecto(nombre) {
      const r = await fetch('/api/cut', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
        body: JSON.stringify({ nombre, perfil: 'musical' }),
      });
      const b = await J(r);
      if (!r.ok) throw new Error('crear proyecto ' + r.status + ' ' + (b.detail || b._raw || ''));
      return b.id;
    },
    async estimar(pid, payload) {
      const r = await fetch(`/api/cut/${pid}/generar/estimar`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
        body: JSON.stringify(payload),
      });
      return { ok: r.ok, status: r.status, ...(await J(r)) };
    },
    async generar(pid, payload) {
      const r = await fetch(`/api/cut/${pid}/generar`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
        body: JSON.stringify(payload),
      });
      const b = await J(r);
      return { ok: r.ok, status: r.status, body: b, detail: b.detail || b._raw || '' };
    },
    async proyecto(pid) { const r = await fetch(`/api/cut/${pid}`, { credentials: 'include' }); return J(r); },
    async cuenta() { const r = await fetch('/api/cuenta', { credentials: 'include' }); return J(r); },
    async listarProyectos() {
      const r = await fetch('/api/cut', { credentials: 'include' });
      const b = await J(r);
      return Array.isArray(b) ? b : (b.items || b.proyectos || []);
    },
    async subirReferencia(pid, file) {
      const fd = new FormData();
      fd.append('archivo', file);
      const r = await fetch(`/api/cut/${pid}/referencias`, { method: 'POST', credentials: 'include', body: fd });
      const b = await J(r);
      if (!r.ok) throw new Error(r.status + ' ' + (b.detail || b._raw || ''));
      return b;
    },
    urlVideo(pid, medioId) { return `/api/cut/${pid}/medios/${medioId}/archivo`; },
  };

  // ---------- 设置持久化 ----------
  function saveSettings() {
    try {
      localStorage.setItem(LS, JSON.stringify({
        prompt: S.prompt, model: S.modelId, name: S.name,
        duration: S.params.duration, resolution: S.params.resolution,
        aspect: S.params.aspect, audio: S.params.audio, proj: S.projSel,
      }));
  } catch (_) {}
  }
  function loadSettings() { try { return JSON.parse(localStorage.getItem(LS) || '{}') || {}; } catch (_) { return {}; } }

  // ---------- 模型/字段 ----------
  const model = () => S.models.find((m) => m.id === S.modelId) || null;
  const entEntries = (m) => Object.entries((m && m.campos) || {}).filter(([, f]) => TIPOS.includes(f.tipo));

  // 模型能力标注 (人话版): 让用户一眼看懂这个模型"能用什么参考"
  function modelTag(m) {
    const ents = entEntries(m);
    if (!ents.length) return '文生视频';
    const imgFields = ents.filter(([, f]) => BASE[f.tipo] === 'imagen');
    const hasVid = ents.some(([, f]) => BASE[f.tipo] === 'video');
    const hasAud = ents.some(([, f]) => BASE[f.tipo] === 'audio');
    const p = [];
    if (imgFields.length >= 2) p.push('首尾帧');
    else if (imgFields.length === 1) {
      const f = imgFields[0][1];
      p.push(f.tipo.endsWith('s') ? `多图参考≤${f.max ?? 1}` : '单图参考');
    }
    if (hasVid) p.push('AI视频');
    if (hasAud) p.push('音频');
    return p.join('+');
  }

  function applyModel(restore) {
    const m = model();
    S.refs = {}; S.entMeta = {};
    for (const [n, f] of entEntries(m)) {
      const plural = f.tipo.endsWith('s');
      S.entMeta[n] = { base: BASE[f.tipo], plural, max: plural ? (f.max ?? 1) : 1 };
    }
    const c = (m && m.campos) || {};
    if (c.duration) {
      S.params.duration = c.duration.def ?? 3;
      if (restore && restore.duration != null && Number(restore.duration) >= (c.duration.min ?? 2) && Number(restore.duration) <= (c.duration.max ?? 30)) S.params.duration = Number(restore.duration);
    }
    if (c.resolution) {
      S.params.resolution = c.resolution.def ?? null;
      if (restore && restore.resolution && (c.resolution.valores || []).includes(restore.resolution)) S.params.resolution = restore.resolution;
    }
    if (c.aspect_ratio) {
      S.params.aspect = c.aspect_ratio.def ?? null;
      if (restore && restore.aspect && (c.aspect_ratio.valores || []).includes(restore.aspect)) S.params.aspect = restore.aspect;
    }
    if (c.generate_audio) S.params.audio = restore && typeof restore.audio === 'boolean' ? restore.audio : !!(c.generate_audio && c.generate_audio.def);
  }

  async function loadCatalog() {
    const c = await API.catalogo();
    S.models = (c.modelos || []).filter((m) => (m.salida ?? 'video') === 'video');
    if (!S.models.length) throw new Error('目录为空');
    if (!S.modelId || !S.models.some((m) => m.id === S.modelId)) {
      const savedModel = S.saved && S.saved.model;
      const pick = S.models.find((m) => m.id === savedModel) || S.models.find((m) => /wan3/i.test(m.id)) || S.models[0];
      S.modelId = pick.id;
    }
    applyModel(S.saved);
    S.saved = null; // 只消费一次
    loadEstilos();
    log('目录加载成功: ' + S.models.length + ' 个视频模型');
  }

  async function loadEstilos() {
    const m = model();
    S.estFields = {};
    if (!m) return;
    const es = Object.entries(m.campos || {}).filter(([, f]) => f.tipo === 'estilo');
    for (const [n, f] of es) {
      const src = f.fuente || 'genjutsu';
      const ef = { requerido: !!f.requerido, options: [], value: null };
      S.estFields[n] = ef;
      try {
        const list = S.estCache[src] || (S.estCache[src] = await API.estilos(src));
        ef.options = list.map((s) => ({ id: s.id, nombre: s.nombre }));
        if (ef.requerido && ef.options[0]) ef.value = ef.options[0].id; // 必选默认第一个
      } catch (e) { log('风格加载失败 ' + e.message, 'err'); }
    }
  }

  // ---------- 项目 ----------
  async function validateProject(pid) {
    try { await API.proyecto(pid); return true; } catch (_) { return false; }
  }
  // 默认项目: 自动建一次, localStorage 记住 pid 复用; 项目被删/账号变化时自动重建
  async function ensureDefaultProject() {
    const saved = (() => { try { return localStorage.getItem('dg_pid'); } catch (_) { return null; } })();
    if (saved && (await validateProject(saved))) {
      if (!S.projSel) S.projSel = saved;
      S.projOk = saved;
      return saved;
    }
    if (saved) { try { localStorage.removeItem('dg_pid'); } catch (_) {} }
    const nid = await API.crearProyecto('Direct Gen');
    try { localStorage.setItem('dg_pid', nid); } catch (_) {}
    if (!S.projSel) S.projSel = nid;
    S.projOk = nid;
    log('默认项目就绪: ' + nid, 'ok');
    return nid;
  }
  // 任何估价/提交都走这里: 项目失效自动切回默认项目 (404 的根源就是记住了已删项目)
  async function ensureProject() {
    if (S.projSel) {
      if (S.projOk === S.projSel) return S.projSel; // 已验证过
      if (await validateProject(S.projSel)) { S.projOk = S.projSel; return S.projSel; }
      log('项目 ' + S.projSel + ' 已不存在, 切回默认项目', 'warn');
      S.projSel = null; S.projOk = null;
    }
    return ensureDefaultProject();
  }
  async function refreshProjects() {
    try {
      const items = await API.listarProyectos();
      S.projects = items.map((p) => ({ id: p.id, label: String(p.nombre || p.id).slice(0, 28) + ' · ' + p.id }));
    } catch (e) { log('项目列表加载失败 ' + e.message, 'warn'); }
  }
  function setProject(id) {
    S.projSel = id;
    S.projOk = id; // 列表里来的项目视为有效
    S.refs = {}; // 参考绑定项目, 换项目必须清空
    S.recent = [];
    refreshRecent();
    estimateSoon();
    saveSettings();
  }

  // ---------- 参考素材 ----------
  function makeThumb(blob) {
    return new Promise((res) => {
      const img = new Image();
      const u = URL.createObjectURL(blob);
      img.onload = () => {
        const c = document.createElement('canvas');
        const s = Math.min(1, 96 / Math.max(img.width || 96, img.height || 96));
        c.width = Math.round((img.width || 96) * s); c.height = Math.round((img.height || 96) * s);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(u);
        res(c.toDataURL('image/jpeg', 0.8));
      };
      img.onerror = () => { URL.revokeObjectURL(u); res(null); };
      img.src = u;
    });
  }

  function addRefEntry(campo, file, label) {
    const meta = S.entMeta[campo];
    if (!meta) return;
    const arr = S.refs[campo] = S.refs[campo] || [];
    if (arr.length >= meta.max) { log(campo + ' 已达上限 ' + meta.max, 'warn'); return; }
    const entry = { kind: 'ref', id: null, label, status: 'up', error: null, thumb: null, file, campo };
    arr.push(entry);
    makeThumb(file).then((t) => { entry.thumb = t; });
    uploadEntry(entry);
  }

  async function uploadEntry(entry) {
    entry.status = 'up'; entry.error = null;
    try {
      const pid = await ensureProject();
      const ref = await API.subirReferencia(pid, entry.file);
      entry.id = ref.id; entry.status = 'done';
      log('参考已上传: ' + ref.id, 'ok');
    } catch (e) {
      entry.status = 'err'; entry.error = String(e.message || e).slice(0, 60);
      log('参考上传失败 ' + entry.error, 'err');
    }
    estimateSoon();
  }

  async function uploadImage({ campo, dataUrl, name }) {
    const blob = await (await fetch(dataUrl)).blob();
    const file = new File([blob], name || 'ref.jpg', { type: blob.type || 'image/jpeg' });
    addRefEntry(campo, file, name || '参考图');
    return { ok: true };
  }

  function removeRef({ campo, idx }) {
    const arr = S.refs[campo] || [];
    arr.splice(idx, 1);
    estimateSoon();
    return { ok: true };
  }
  function retryRef({ campo, idx }) {
    const entry = (S.refs[campo] || [])[idx];
    if (entry && entry.file) uploadEntry(entry);
    return { ok: true };
  }

  async function waitRefsSettled(timeoutMs = 60000) {
    const t0 = Date.now();
    while (Object.values(S.refs).flat().some((e) => e.status === 'up')) {
      if (Date.now() - t0 > timeoutMs) break;
      await sleep(500);
    }
  }

  // ---------- payload / 校验 ----------
  function buildPayload() {
    const m = model();
    if (!m) throw new Error('模型目录未加载');
    const c = m.campos || {};
    const p = {};
    if (S.prompt.trim()) p.prompt = S.prompt.trim(); // 空字符串字段直接省略
    const e = {};
    for (const [name, campo] of Object.entries(c)) {
      if (TIPOS.includes(campo.tipo)) {
        const vals = (S.refs[name] || []).filter((v) => v.status === 'done'); // 只提交已就绪的参考
        if (vals.length) e[name] = vals.map((v) => ({ tipo: v.kind === 'ai' ? 'generacion' : 'referencia', id: v.id }));
      } else if (name === 'duration') p[name] = Number(S.params.duration);
      else if (name === 'resolution') p[name] = S.params.resolution;
      else if (name === 'aspect_ratio') p[name] = S.params.aspect;
      else if (name === 'generate_audio') p[name] = !!S.params.audio;
      else if (campo.tipo === 'estilo') { if (S.estFields[name] && S.estFields[name].value) p[name] = S.estFields[name].value; }
      else if (campo.def !== undefined && name !== 'prompt') p[name] = campo.def;
    }
    return { modelo: m.id, parametros: p, entradas: e, nombre: (S.name || 'Direct Gen').slice(0, 60) };
  }

  function validate(m) {
    const errs = [];
    for (const [n, f] of entEntries(m)) {
      if (f.requerido && !(S.refs[n] || []).some((v) => v.status === 'done')) errs.push('缺少必选参考: ' + n);
    }
    for (const [n, f] of Object.entries(m.campos || {})) {
      if (f.tipo === 'estilo' && f.requerido && !(S.estFields[n] && S.estFields[n].value)) errs.push('缺少必选风格: ' + n);
    }
    if (m.campos.prompt && m.campos.prompt.requerido && !S.prompt.trim()) errs.push('请先填写 prompt');
    return errs;
  }

  function fmtErr(res) {
    if (res.status === 402) return '402 积分不足';
    if (res.status === 507) return '507 存储满 — ' + res.detail;
    return res.status + ' — ' + (res.detail || '');
  }

  // ---------- 估价 / 余额 ----------
  async function refreshBalance() {
    try {
      const c = await API.cuenta();
      S.balance = Number(c.creditos || 0) + Number(c.creditos_extra || 0);
      return S.balance;
    } catch (_) { S.balance = null; return null; }
  }
  // 价格实时跟随: 模型/参数/参考一动就重新报价 (150ms 内), 失败时把原因带到费用行
  function estimateSoon() { clearTimeout(S.estTimer); S.estTimer = setTimeout(liveEstimate, 150); }
  async function liveEstimate() {
    const seq = (S.estSeq = (S.estSeq || 0) + 1);
    if (!S.modelId) { S.cost = null; return; }
    try {
      let pid = await ensureProject();
      let est = await API.estimar(pid, buildPayload());
      if (!est.ok && est.status === 404) {
        // 项目失效 (账号切换/被删): 清掉重建再估
        S.projSel = null; S.projOk = null;
        try { localStorage.removeItem('dg_pid'); } catch (_) {}
        pid = await ensureDefaultProject();
        est = await API.estimar(pid, buildPayload());
      }
      if (seq === S.estSeq) S.cost = est.ok ? { creditos: est.creditos } : { error: fmtErr(est) };
    } catch (e) {
      if (seq === S.estSeq) S.cost = { error: String((e && e.message) || e) };
    }
  }
  // ---------- 生成: 校验 -> 提交 (费用平时就在费用行显示, 提交前静默复核) ----------
  async function generate() {
    const m = model();
    if (!m) return { ok: false, error: '模型目录未加载, 稍等几秒' };
    if (Object.values(S.refs).flat().some((e) => e.status === 'up')) {
      log('等待参考上传完成…');
      await waitRefsSettled();
    }
    const errs = validate(m);
    if (errs.length) return { ok: false, error: errs.join('; ') };
    const errN = Object.values(S.refs).flat().filter((v) => v.status === 'err').length;
    if (errN) log(errN + ' 项参考上传失败, 将被跳过', 'warn');
    const payload = buildPayload();
    const pid = await ensureProject();
    const est = await API.estimar(pid, payload);
    if (!est.ok) return { ok: false, error: '价格检查失败 ' + fmtErr(est) };
    const have = await refreshBalance();
    if (typeof have === 'number' && est.creditos > have) return { ok: false, error: '积分不足: 需要 ' + est.creditos + ', 持有 ' + have };
    const gen = await API.generar(pid, payload);
    if (!gen.ok) return { ok: false, error: fmtErr(gen) };
    const job = { pid, gid: gen.body.id, name: payload.nombre, startedAt: Date.now(), state: 'run', msg: '' };
    S.jobs.unshift(job);
    if (S.jobs.length > 6) S.jobs.pop();
    startPoll(job);
    refreshBalance();
    log('✅ 已受理! ' + est.creditos + ' 积分 · 任务 ' + job.gid, 'ok');
    return { ok: true, gid: job.gid, creditos: est.creditos, have };
  }

  // ---------- 任务轮询 (引擎侧, popup 关了也继续) ----------
  function startPoll(job) {
    (async () => {
      for (let i = 0; i < 80; i++) {
        await sleep(15000);
        try {
          const p = await API.proyecto(job.pid);
          const g = (p.generaciones || []).find((x) => x.id === job.gid);
          if (!g) { job.state = 'err'; job.msg = '任务对象未找到'; return; }
          if (g.estado === 'listo') {
            const medio = Object.values(p.medios || {}).find((m) => m.generado && m.generado.id === job.gid);
            job.state = 'done';
            job.videoUrl = medio ? location.origin + API.urlVideo(job.pid, medio.id) : null;
            job.downloadName = ((medio && medio.nombre) || job.name) + '.mp4';
            log('🎉 生成完成: ' + ((medio && medio.nombre) || job.gid), 'ok');
            refreshBalance();
            refreshRecent();
            return;
          }
          if (g.estado === 'error') { job.state = 'err'; job.msg = '生成失败: ' + (g.error || '未知'); log(job.msg, 'err'); return; }
        } catch (_) {}
      }
      job.state = 'timeout'; job.msg = '轮询超时, 去站点页面查看结果';
    })();
  }

  // ---------- 最近生成 ----------
  async function refreshRecent() {
    const pid = S.projSel;
    if (!pid) { S.recent = []; return; }
    try {
      const p = await API.proyecto(pid);
      S.recent = (p.generaciones || []).slice().reverse().slice(0, 8).map((g) => {
        const medio = Object.values(p.medios || {}).find((m) => m.generado && m.generado.id === g.id);
        return {
          id: g.id, nombre: g.nombre || g.id, estado: g.estado, model: g.nombre_modelo || '',
          error: g.error || null,
          size: medio ? Math.round((medio.tamano / 1048576) * 10) / 10 : null,
          videoUrl: medio && g.estado === 'listo' ? location.origin + API.urlVideo(pid, medio.id) : null,
        };
      });
    } catch (e) { log('最近生成加载失败 ' + e.message, 'warn'); }
  }

  // ---------- 状态快照 (popup 每 2s 拉取) ----------
  function snapshot() {
    const m = model();
    const c = (m && m.campos) || {};
    return {
      ok: true,
      host: location.host,
      catalogReady: !!S.catalog || S.models.length > 0,
      defaultPid: (() => { try { return localStorage.getItem('dg_pid'); } catch (_) { return null; } })(),
      models: S.models.map((x) => ({ id: x.id, label: `${x.modelo} · ${modelTag(x)} (${x.id})` })),
      modelId: S.modelId,
      projects: S.projects,
      projSel: S.projSel,
      name: S.name,
      prompt: S.prompt,
      params: { ...S.params },
      campos: {
        duration: c.duration ? { min: c.duration.min ?? 2, max: c.duration.max ?? 30, def: c.duration.def ?? 3 } : null,
        resolution: c.resolution ? { valores: c.resolution.valores || [], def: c.resolution.def } : null,
        aspect: c.aspect_ratio ? { valores: c.aspect_ratio.valores || [], def: c.aspect_ratio.def } : null,
        audio: !!c.generate_audio,
      },
      refFields: entEntries(m).map(([n, f]) => ({
        name: n, base: BASE[f.tipo],
        plural: f.tipo.endsWith('s'), max: f.tipo.endsWith('s') ? (f.max ?? 1) : 1,
        cards: (S.refs[n] || []).map((e) => ({ label: e.label, status: e.status, error: e.error, thumb: e.thumb || null, kind: e.kind })),
      })),
      estFields: Object.entries(S.estFields).map(([n, v]) => ({ name: n, requerido: v.requerido, options: v.options, value: v.value })),
      balance: S.balance,
      cost: S.cost,
      jobs: S.jobs.map((j) => ({ gid: j.gid, name: j.name, startedAt: j.startedAt, state: j.state, msg: j.msg || '', videoUrl: j.videoUrl || null, downloadName: j.downloadName || null })),
      recent: S.recent,
      logs: S.logs.slice(-60),
    };
  }

  // ---------- 消息总线 ----------
  async function handle(msg) {
    switch (msg.t) {
      case 'ping': return { ok: true, host: location.host };
      case 'snapshot': return snapshot();
      case 'setProject': setProject(msg.id); return { ok: true };
      case 'setModel':
        S.modelId = msg.id; S.refs = {};
        applyModel(null); loadEstilos(); liveEstimate(); saveSettings(); // 换模型立即显示积分
        return { ok: true };
      case 'setName': S.name = String(msg.v || '').slice(0, 60); saveSettings(); return { ok: true };
      case 'setPrompt': S.prompt = String(msg.v || ''); saveSettings(); return { ok: true };
      case 'setParam':
        S.params[msg.k] = msg.k === 'audio' ? !!msg.v : msg.v;
        estimateSoon(); saveSettings();
        return { ok: true };
      case 'setEstilo':
        if (S.estFields[msg.campo]) { S.estFields[msg.campo].value = msg.id || null; estimateSoon(); }
        return { ok: true };
      case 'uploadImage': return uploadImage(msg);
      case 'removeRef': return removeRef(msg);
      case 'retryRef': return retryRef(msg);
      case 'generate': return generate();
      case 'refreshRecent': await refreshRecent(); return { ok: true };
      case 'refreshAll': await Promise.all([refreshProjects(), refreshBalance()]); return { ok: true };
      default: return { ok: false, error: 'unknown action ' + msg.t };
    }
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    handle(msg).then((r) => sendResponse(r || { ok: true })).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true; // async response
  });

  // ---------- boot ----------
  (async () => {
    S.saved = loadSettings();
    if (S.saved) {
      S.prompt = S.saved.prompt || '';
      S.name = S.saved.name || '';
      S.projSel = S.saved.proj && S.saved.proj !== '__new__' ? S.saved.proj : null;
    }
    refreshBalance();
    refreshProjects().then(async () => {
      // 上次选的项目可能已被删/换账号: 先验证, 失效就回默认项目
      if (S.projSel && !(await validateProject(S.projSel))) {
        log('上次的项目已不存在, 回到默认项目', 'warn');
        S.projSel = null;
        saveSettings();
      }
    });
    loadCatalog()
      .then(async () => {
        // 目录就绪 → 确保默认项目 → 立即出实时报价 (打开弹窗就能看到积分消耗)
        try {
          await ensureDefaultProject();
          estimateSoon();
        } catch (e) { log('默认项目创建失败: ' + (e.message || e), 'err'); }
      })
      .catch((e) => log('目录加载失败 ' + e.message + ' — 刷新页面重试', 'err'));
    refreshRecent();
  })();
})();
