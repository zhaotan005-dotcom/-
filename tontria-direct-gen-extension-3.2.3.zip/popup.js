/*
 * Direct Gen v3.1.0 — popup UI (ShopOS 式弹窗)
 * 所有操作通过 chrome.tabs.sendMessage 转发给页面侧 engine.js 执行 (fetch 同源带登录 cookie)
 * 生成: 点一次直接提交; 费用行选完模型即显示积分
 */
'use strict';

const $ = (s) => document.querySelector(s);
const els = {};
['balance', 'tip', 'tipReason', 'recheck', 'app', 'proj', 'model', 'name', 'refSection',
  'prompt', 'clearPrompt', 'duration', 'resolution', 'aspect', 'audio',
  'fDur', 'fRes', 'fAsp', 'fAud', 'estSection', 'cost', 'costHint',
  'generate', 'msg', 'jobs', 'refresh', 'results', 'log'].forEach((k) => (els[k] = $('#' + k)));

let tabId = null;
let snap = null;
let genBusy = false;
let lastKeys = {};        // 渲染去重

const HOST_RE = /^https:\/\/(motionstudio|clips)\.tontria\.com\/app/;

async function send(msg) {
  try {
    return await chrome.tabs.sendMessage(tabId, msg);
  } catch (e) {
    return { ok: false, error: '与页面通信失败 — 请刷新 Motion Studio 页面后重开本扩展' };
  }
}

function setMsg(text, cls) {
  els.msg.textContent = text || '';
  els.msg.className = 'msg' + (cls ? ' ' + cls : '');
}

function fileToDataUrl(f) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsDataURL(f);
  });
}

// 强制下载: 跨源 URL 的 <a download> 不生效, 先 fetch 成 blob 再下载
async function downloadVideo(url, name) {
  try {
    setMsg('下载中… ' + name);
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const b = await r.blob();
    const u = URL.createObjectURL(b);
    const a = document.createElement('a');
    a.href = u; a.download = name || 'direct-gen.mp4';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(u), 20000);
    setMsg('已开始下载 ' + name, 'ok');
  } catch (e) {
    setMsg('下载失败 ' + e.message, 'err');
  }
}

function pickFile(accept, multiple, cb) {
  const inp = document.createElement('input');
  inp.type = 'file'; inp.accept = accept;
  if (multiple) inp.multiple = true;
  inp.style.display = 'none';
  document.body.appendChild(inp);
  inp.addEventListener('change', () => { if (inp.files.length) cb([...inp.files]); inp.remove(); });
  inp.click();
}

// ============ boot ============
(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !HOST_RE.test(tab.url || '')) {
    els.tipReason.textContent = '未检测到 Motion Studio 页面 (当前标签页不是站点 App 页面)。';
    els.tip.classList.remove('hidden');
    return;
  }
  tabId = tab.id;
  const p = await send({ t: 'ping' });
  if (!p || !p.ok) {
    els.tipReason.textContent = '扩展未能在页面上激活 — 请刷新 Motion Studio 页面 (地址需含 /app), 再重新打开本扩展。';
    els.tip.classList.remove('hidden');
    return;
  }
  els.tip.classList.add('hidden');
  els.app.classList.remove('hidden');

  bindEvents();
  await refresh(true);
  setInterval(refresh, 1000);
})();

els.recheck.addEventListener('click', () => location.reload());

// ============ 事件绑定 (一次) ============
function bindEvents() {
  els.proj.addEventListener('change', async () => {
    await send({ t: 'setProject', id: els.proj.value });
    setMsg('');
    refresh();
  });
  els.model.addEventListener('change', async () => {
    await send({ t: 'setModel', id: els.model.value });
    setMsg('');
    refresh();
  });
  let nameT = null;
  els.name.addEventListener('input', () => {
    clearTimeout(nameT);
    nameT = setTimeout(() => send({ t: 'setName', v: els.name.value }), 300);
  });
  let promptT = null;
  els.prompt.addEventListener('input', () => {
    clearTimeout(promptT);
    promptT = setTimeout(() => send({ t: 'setPrompt', v: els.prompt.value }), 400);
  });
  els.clearPrompt.addEventListener('click', () => { els.prompt.value = ''; send({ t: 'setPrompt', v: '' }); setMsg(''); });
  els.duration.addEventListener('change', () => { send({ t: 'setParam', k: 'duration', v: Number(els.duration.value) }); });
  els.resolution.addEventListener('change', () => { send({ t: 'setParam', k: 'resolution', v: els.resolution.value }); });
  els.aspect.addEventListener('change', () => { send({ t: 'setParam', k: 'aspect', v: els.aspect.value }); });
  els.audio.addEventListener('change', () => { send({ t: 'setParam', k: 'audio', v: els.audio.checked }); });
  els.refresh.addEventListener('click', async () => { await send({ t: 'refreshAll' }); await send({ t: 'refreshRecent' }); refresh(); });

  // 生成: 点一次直接提交 (费用行已显示积分)
  els.generate.addEventListener('click', async () => {
    if (genBusy) return;
    genBusy = true;
    els.generate.disabled = true;
    els.generate.textContent = '提交中…';
    try {
      setMsg('检查参考/必填项/积分…');
      const r = await send({ t: 'generate' });
      if (!r.ok) setMsg(r.error, 'err');
      else setMsg('已受理 (' + (r.creditos ?? '?') + ' 积分) — 可关掉本窗口, 任务照常进行', 'ok');
    } finally {
      genBusy = false;
      els.generate.textContent = '生成';
      els.generate.disabled = false;
      refresh();
    }
  });
}

// ============ 渲染 ============
async function refresh(force) {
  snap = await send({ t: 'snapshot' });
  if (!snap || !snap.ok) return;

  // 余额
  els.balance.textContent = snap.balance == null ? '积分 ?' : '积分 ' + snap.balance;

  // 项目/模型下拉 (仅列表变化时重建, 避免打断用户浏览)
  // 项目列表 = 默认项目(Direct Gen, 常驻) + 其余项目, 选中任意一个都能实时估价
  const projItems = [];
  if (snap.defaultPid) projItems.push({ id: snap.defaultPid, label: '🎬 Direct Gen (默认)' });
  for (const p of snap.projects || []) {
    if (p.id !== snap.defaultPid) projItems.push(p);
  }
  rebuildSelect(els.proj, projItems, snap.projSel, () => lastKeys.proj, (v) => (lastKeys.proj = v));
  rebuildSelect(els.model, snap.models || [], snap.modelId, () => lastKeys.model, (v) => (lastKeys.model = v));

  // 名称 / 提示词 (用户未聚焦时才回填, 防止输入被打断)
  if (document.activeElement !== els.name && els.name.value !== snap.name) els.name.value = snap.name || '';
  if (document.activeElement !== els.prompt && els.prompt.value !== snap.prompt) els.prompt.value = snap.prompt || '';

  // 参数区
  const c = snap.campos || {};
  els.fDur.style.display = c.duration ? '' : 'none';
  els.fRes.style.display = c.resolution ? '' : 'none';
  els.fAsp.style.display = c.aspect ? '' : 'none';
  els.fAud.style.display = c.audio ? '' : 'none';
  if (c.duration) {
    els.duration.min = c.duration.min; els.duration.max = c.duration.max;
    if (document.activeElement !== els.duration) els.duration.value = snap.params.duration;
  }
  rebuildSelect(els.resolution, (c.resolution ? c.resolution.valores : []).map((v) => ({ id: v, label: v })), snap.params.resolution, () => lastKeys.res, (v) => (lastKeys.res = v));
  rebuildSelect(els.aspect, (c.aspect ? c.aspect.valores : []).map((v) => ({ id: v, label: v })), snap.params.aspect, () => lastKeys.asp, (v) => (lastKeys.asp = v));
  els.audio.checked = !!snap.params.audio;

  renderRefs(force);
  renderEstilos();
  renderCost();
  renderJobs();
  renderRecent();
  renderLogs();

  if (!snap.catalogReady) els.generate.disabled = true;
  else if (!genBusy) els.generate.disabled = false;
}

function rebuildSelect(sel, items, cur, getKey, setKey) {
  const key = items.map((x) => x.id).join('|');
  if (getKey() === key) {
    if (sel.value !== cur && [...sel.options].some((o) => o.value === cur)) sel.value = cur;
    return;
  }
  setKey(key);
  sel.innerHTML = '';
  for (const it of items) {
    const o = document.createElement('option');
    o.value = it.id;
    o.textContent = it.label;
    sel.appendChild(o);
  }
  if ([...sel.options].some((o) => o.value === cur)) sel.value = cur;
}

// —— 参考区 (按模型字段渲染) ——
const BASE_CN = { imagen: '图片', video: 'AI视频', audio: '音频' };

function renderRefs(force) {
  const fields = snap.refFields || [];
  const key = JSON.stringify(fields.map((f) => [f.name, f.base, f.plural, f.max, f.cards.map((cd) => [cd.label, cd.status, cd.error])]));
  if (!force && lastKeys.refs === key) return;
  lastKeys.refs = key;

  const host = els.refSection;
  host.innerHTML = '';
  if (!fields.length) {
    const d = document.createElement('div');
    d.className = 'empty';
    d.textContent = '此模型无参考图字段 (纯文生视频)';
    host.appendChild(d);
    return;
  }
  for (const f of fields) {
    if (f.base !== 'imagen') continue; // 视频参考 (复用 AI 视频) / 音频参考不上 UI
    const sec = document.createElement('div');
    sec.className = 'ref-field';

    const head = document.createElement('div');
    head.className = 'rf-head';
    const lbl = document.createElement('span');
    lbl.textContent = `参考 · ${f.name} (${BASE_CN[f.base] || f.base}${f.plural ? ' · 最多 ' + f.max + ' 项' : ''})`;
    const cnt = document.createElement('span');
    cnt.className = 'cnt';
    cnt.textContent = f.plural ? `${f.cards.length}/${f.max}` : (f.cards.length ? '✓' : '');
    head.append(lbl, cnt);
    sec.appendChild(head);

    if (f.base === 'imagen') {
      // 添加参考图
      const add = document.createElement('label');
      add.className = 'ref-add';
      add.textContent = f.plural ? '＋ 添加参考图 (可多选)' : '＋ 添加参考图';
      add.addEventListener('click', () => {
        pickFile('image/jpeg,image/png,image/webp', f.plural, async (files) => {
          for (const file of files) {
            const dataUrl = await fileToDataUrl(file);
            await send({ t: 'uploadImage', campo: f.name, dataUrl, name: file.name });
          }
          setMsg('');
          refresh();
        });
      });
      sec.appendChild(add);
    }

    // 参考卡片列表
    if (f.cards.length) {
      const list = document.createElement('div');
      list.className = 'ref-list';
      f.cards.forEach((cd, idx) => {
        const item = document.createElement('div');
        item.className = 'ref-item';
        if (cd.thumb) {
          const img = document.createElement('img');
          img.className = 'thumb'; img.src = cd.thumb; img.alt = '';
          item.appendChild(img);
        } else {
          const ic = document.createElement('div');
          ic.className = 'thumb icon';
          ic.textContent = cd.kind === 'ai' ? 'AI' : 'IMG';
          item.appendChild(ic);
        }
        const info = document.createElement('div');
        info.className = 'info';
        const nm = document.createElement('div');
        nm.className = 'name'; nm.textContent = cd.label; nm.title = cd.label;
        const st = document.createElement('div');
        st.className = 'st ' + cd.status;
        st.textContent = cd.status === 'up' ? '上传中…'
          : cd.status === 'err' ? '失败 · ' + (cd.error || '可重试')
          : (cd.kind === 'ai' ? '已就绪 · 项目 AI 视频' : '已就绪 · ref ' + (cd.id || ''));
        info.append(nm, st);
        item.appendChild(info);
        if (cd.status === 'err') {
          const rt = document.createElement('button');
          rt.type = 'button'; rt.className = 'retry'; rt.textContent = '↻'; rt.title = '重新上传';
          rt.addEventListener('click', async () => { await send({ t: 'retryRef', campo: f.name, idx }); refresh(); });
          item.appendChild(rt);
        }
        const del = document.createElement('button');
        del.type = 'button'; del.className = 'del'; del.textContent = '✕'; del.title = '移除';
        del.addEventListener('click', async () => { await send({ t: 'removeRef', campo: f.name, idx }); refresh(); });
        item.appendChild(del);
        list.appendChild(item);
      });
      sec.appendChild(list);
    }
    host.appendChild(sec);
  }
}

// —— 风格 ——
function renderEstilos() {
  const fields = snap.estFields || [];
  const host = els.estSection;
  const key = JSON.stringify(fields.map((f) => [f.name, f.value, f.options.map((o) => o.id)]));
  if (lastKeys.est === key) return;
  lastKeys.est = key;
  host.innerHTML = '';
  for (const f of fields) {
    const wrap = document.createElement('label');
    wrap.className = 'field';
    wrap.style.marginBottom = '10px';
    const sp = document.createElement('span');
    sp.textContent = `风格 · ${f.name}${f.requerido ? ' (必选)' : ''}`;
    const sel = document.createElement('select');
    if (!f.requerido) {
      const o = document.createElement('option');
      o.value = ''; o.textContent = '— 无风格 —';
      sel.appendChild(o);
    }
    for (const op of f.options) {
      const o = document.createElement('option');
      o.value = op.id; o.textContent = op.nombre;
      sel.appendChild(o);
    }
    if ([...sel.options].some((o) => o.value === f.value)) sel.value = f.value || '';
    sel.addEventListener('change', () => send({ t: 'setEstilo', campo: f.name, id: sel.value }));
    wrap.append(sp, sel);
    host.appendChild(wrap);
  }
}

// —— 费用行: 永远可见, 有价格显示价格, 没有就显示原因 ——
function renderCost() {
  if (snap.cost && snap.cost.creditos != null) {
    els.cost.innerHTML = '费用 <b>' + snap.cost.creditos + '</b> 积分';
    els.costHint.textContent = '';
  } else if (snap.cost && snap.cost.error) {
    els.cost.innerHTML = '费用 <b>?</b>';
    els.costHint.textContent = String(snap.cost.error).slice(0, 60);
  } else {
    els.cost.innerHTML = '费用 <b>?</b>';
    els.costHint.textContent = '等模型/项目就绪';
  }
}

// —— 任务卡 ——
function renderJobs() {
  const jobs = snap.jobs || [];
  const key = jobs.map((j) => [j.gid, j.state, j.msg].join(':')).join('|');
  const changed = lastKeys.jobs !== key;
  lastKeys.jobs = key;
  const host = els.jobs;
  if (!jobs.length) {
    if (changed) host.innerHTML = '';
    return;
  }
  // 计时每秒本地更新: 简化处理, 跟随 2s 轮询重绘
  host.innerHTML = '';
  for (const j of jobs.slice(0, 4)) {
    const card = document.createElement('div');
    card.className = 'job';
    const txt = document.createElement('div');
    txt.className = 'job-text';
    if (j.state === 'run') {
      txt.textContent = `生成中… ${Math.round((Date.now() - j.startedAt) / 1000)}s (${j.name})`;
      const bar = document.createElement('div');
      bar.className = 'bar';
      bar.innerHTML = '<div class="bar-fill"></div>';
      card.append(txt, bar);
    } else if (j.state === 'done') {
      txt.innerHTML = '';
      const ok = document.createElement('span');
      ok.textContent = `生成完成 (${j.name}) `;
      ok.style.color = 'var(--ok)';
      const dl = document.createElement('a');
      dl.href = '#';
      dl.textContent = '下载';
      dl.style.color = 'var(--accent)';
      dl.addEventListener('click', (e) => { e.preventDefault(); downloadVideo(j.videoUrl, j.downloadName); });
      txt.append(ok, dl);
      card.appendChild(txt);
      if (j.videoUrl) {
        const v = document.createElement('video');
        v.controls = true; v.playsInline = true; v.preload = 'metadata'; v.src = j.videoUrl;
        card.appendChild(v);
      }
    } else {
      txt.textContent = j.msg || '任务结束';
      txt.style.color = 'var(--err)';
      card.appendChild(txt);
    }
    host.appendChild(card);
  }
}

// —— 最近生成 ——
function renderRecent() {
  const rec = snap.recent || [];
  const key = rec.map((r) => [r.id, r.estado].join(':')).join('|');
  if (lastKeys.recent === key) return;
  lastKeys.recent = key;
  const host = els.results;
  host.innerHTML = '';
  if (!rec.length) {
    const d = document.createElement('div');
    d.className = 'empty';
    d.textContent = '(当前项目的生成结果会显示在这里)';
    host.appendChild(d);
    return;
  }
  for (const g of rec) {
    const item = document.createElement('div');
    item.className = 'item';
    const meta = document.createElement('div');
    meta.className = 'meta';
    const badge = document.createElement('span');
    badge.className = 'badge ' + (g.estado === 'listo' ? 'completed' : g.estado === 'error' ? 'failed' : 'processing');
    badge.textContent = g.estado === 'listo' ? '完成' : g.estado === 'error' ? '失败' : '生成中';
    const nm = document.createElement('span');
    nm.className = 'nm'; nm.textContent = g.nombre; nm.title = g.nombre;
    const md = document.createElement('span');
    md.textContent = [g.model, g.size != null ? g.size + ' MB' : ''].filter(Boolean).join(' · ');
    meta.append(badge, nm, md);
    item.appendChild(meta);
    if (g.error) {
      const em = document.createElement('div');
      em.className = 'errline';
      em.textContent = g.error;
      item.appendChild(em);
    }
    if (g.videoUrl) {
      const v = document.createElement('video');
      v.controls = true; v.playsInline = true; v.preload = 'metadata'; v.src = g.videoUrl;
      item.appendChild(v);
      const acts = document.createElement('div');
      acts.className = 'acts';
      const dl = document.createElement('button');
      dl.type = 'button'; dl.className = 'hl'; dl.textContent = '下载';
      dl.addEventListener('click', () => downloadVideo(g.videoUrl, g.nombre + '.mp4'));
      acts.appendChild(dl);
      item.appendChild(acts);
    }
    host.appendChild(item);
  }
}

// —— 日志 ——
function renderLogs() {
  const logs = snap.logs || [];
  if (lastKeys.logN === logs.length && lastKeys.log0 === (logs[0] && logs[0].t)) return;
  lastKeys.logN = logs.length;
  lastKeys.log0 = logs[0] && logs[0].t;
  const host = els.log;
  host.innerHTML = '';
  for (const l of logs) {
    const line = document.createElement('div');
    if (l.cls) line.className = l.cls;
    line.textContent = new Date(l.t).toLocaleTimeString() + ' ' + l.msg;
    host.appendChild(line);
  }
  host.scrollTop = host.scrollHeight;
}
